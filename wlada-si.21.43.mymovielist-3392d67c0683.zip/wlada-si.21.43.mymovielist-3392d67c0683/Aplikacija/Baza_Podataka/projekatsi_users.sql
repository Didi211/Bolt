-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: projekatsi
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(40) NOT NULL,
  `password` varchar(80) NOT NULL,
  `email` varchar(45) NOT NULL,
  `bio` varchar(80) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(45) NOT NULL,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('DjHomer','lala123','homer@gmail.com','Ja sam Luka, i zivim u Nisu, lep pozdrav',1,'member','Luka','Radojkovic'),('ashabath','aas1222','ementaler23@gmail.com',NULL,12,'member',NULL,NULL),('lokvanj123','asasasq1','pekic121@hotmail.com',NULL,13,'member',NULL,NULL),('islamabad190','kreativnost','gaudi198@hotmail.com',NULL,14,'member',NULL,NULL),('lokolokoa','fsdgsew4','qwopi@gmail.com',NULL,15,'member',NULL,NULL),('DjJinzo','jinzo123','nomadland@gmail.com',NULL,16,'member','Dejan','Milivojevic'),('popokatepetl','sifra123','sad@gmail.com',NULL,17,'member','asad','asadca'),('qwertop123','asasa123','sar@gmail.com',NULL,18,'member','asqeq','fasfgaega'),('lokoloko','asasa123','dssdv@hotmail.com',NULL,19,'member','saqeqdq','fawfwaqfwq'),('fjds411','asasa123','fsfa@gmail.com',NULL,20,'member','asafgasehgb','gsegsegs'),('gjsdaigas','asada221','fdsafas@gmail.com',NULL,21,'member','asfag','gagaga'),('asasq','saa123','hsdhsd@gmail.com',NULL,22,'member','fashshrj','hwrshws'),('asasalokotestmeelosh','sifrica12113','nekasifricaasasi@gmail.com',NULL,23,'member','Peaatar','Peraaicic'),('voljela','nijedna','azra@hotmail.com',NULL,24,'member','Dzoni','Stulic'),('RadiBre','$2b$10$.XSrHs0NktRZuOB2493rwushv19bzYvohCW8.kcisGRuS09UqD7Ey','saassa@hotmail.com',NULL,25,'member','Saban','Bajramovic'),('Anic99a','$2b$10$c4vaU1wdJUgWefUGcKQAd.7sJSSkOjsvVyK1gkN.ZHC.dFgw7ceKu','kiticpitic@gmail.com',NULL,26,'member','Andrija','Jovanovic'),('glavo','$2b$10$geP.XSQP.g0S6t3iZczpQORmWBuGPca0L8aalYA9tJBGlVWkFpac.','zdravko@hotmail.com',NULL,27,'member','Zdravko','Colic'),('minut','$2b$10$Mh0DMBxVoW7dnvDuKkix.ONCbkebhVs9LbY4c958yMR0aGp6B4tIC','saki2@gmail.com',NULL,28,'member','Sinan','Sakic');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-22 14:17:40
