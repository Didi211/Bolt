const db = require('../config/db.config');
const { getMovieByID } = require('./movies.model');



let date_ob = new Date();
let date = ("0" + date_ob.getDate()).slice(-2);
let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
let year = date_ob.getFullYear();
let hours = date_ob.getHours();
let minutes = date_ob.getMinutes();
let seconds = date_ob.getSeconds();


const getReviews= (result) => {
    db.query(`SELECT * FROM reviews`, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      result(null, res);
    });
}
const getReviewsByUserID = (id,result) => {
  db.query(`SELECT * FROM reviews where user_id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
}
const getReviewsByMovieID = (id,result) => {
  db.query(`SELECT * FROM reviews where movie_id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
}
const getReviewsByID = (id,result) => {
  db.query(`SELECT * FROM reviews where id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
}
const addReview = (movie,user,review,result) => {
  db.query(`INSERT INTO reviews (movie_id, user_id, rating, description, date_time) VALUES ('${movie.id}','${user}', '${review.rating}','${review.description}','${year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds}')`, (err,res) =>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    let new_vote_count = parseInt(movie.vote_count) + 1
    let new_vote_average = (parseInt(movie.vote_count)*parseInt(movie.vote_average) + parseInt(review.rating))/new_vote_count

    db.query(`UPDATE movies SET vote_average = '${new_vote_average}', vote_count = '${new_vote_count}' WHERE (id = '${movie.id}')`)
    result(null, res);
  })
}


const updateReview = (review,result) => {
  db.query(`UPDATE reviews SET rating = '${review.rating}', description = '${review.description}' WHERE (user_id = '${review.user_id}' AND movie_id = '${review.movie_id}')`, (err,res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    getMovieByID(review.movie_id,(err,movie)=> {
        if(err){
            console.log("error: ", err);
            result(null, err);
        }else{
            let new_vote_average = (parseInt(movie[0].vote_count)*parseFloat(movie[0].vote_average) + parseInt(review.rating)- parseInt(review.old_rating))/parseInt(movie[0].vote_count)       
            db.query(`UPDATE movies SET vote_average = '${new_vote_average}' WHERE (id = '${review.movie_id}')`, (err,res1) => {
              if (err) {
                console.log("error: ", err);
                result(null, err);
                return;
              }else{
               
                result(null, res1);
              }
            })            
        }
    })    
  })
}
const deleteReview = (review,result) => {
  db.query(`DELETE FROM reviews WHERE id = ${review.id}`,(err,res)=>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    getMovieByID(review.movie_id,(err,movie)=> {
      if(err){
          console.log("error: ", err);
          result(null, err);
      }else{
          console.log(movie);
          let new_vote_count = parseInt(movie[0].vote_count) - 1
          let new_vote_average = (parseInt(movie[0].vote_count)*parseFloat(movie[0].vote_average) - parseInt(review.rating))/(new_vote_count)  
          console.log(new_vote_average);     
          db.query(`UPDATE movies SET vote_average = '${new_vote_average}', vote_count = '${new_vote_count}' WHERE (id = '${review.movie_id}')`, (err,res1) => {
            if (err) {
              console.log("error: ", err);
              result(null, err);
              return;
            }else{             
              result(null, res1);
            }
          })            
      }
  })     
  })
}
const deleteReviews = (user_id,result) => {

  getReviewsByUserID(user_id,(err,data) =>{
    if(err){
    console.log(err);
    return
    }
    else{
      data.forEach(element => {
        console.log(element);
        deleteReview(element,(err,data)=>{
          if(err){
            console.log(err);
            return
          }          
        })        
      });
      result(null,data)
    }
  })  
}



module.exports = 
{
    getReviews,
    getReviewsByID,
    getReviewsByUserID,
    addReview,
    updateReview,
    deleteReview,
    deleteReviews,
    getReviewsByMovieID
}