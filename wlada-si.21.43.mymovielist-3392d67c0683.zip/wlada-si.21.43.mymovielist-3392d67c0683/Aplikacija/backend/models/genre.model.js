const db = require('../config/db.config')

const getGenres = result => {
  db.query(`SELECT * FROM genres`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
};

const getGenreByID = (genreID, result) => {
  db.query(`SELECT * FROM genres WHERE id = ${genreID}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
};

const getGenreByMovieID = (movieID, result) => {
  
  db.query(`SELECT * FROM genres WHERE id = ANY(SELECT genre_id from movies_genres WHERE movie_id = ${movieID})`, (err, res2) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res2);
  })
};

const getGenreByName = (genreName, result) => {
  db.query(`SELECT * FROM genres WHERE id = ${genreName}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
};

const deleteGenre = (genreID, result) => {
  db.query(`DELETE * FROM genres WHERE id = ${genreID}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
};

const addGenre = (genre, result) => {
  db.query(`INSER INTO gernes ('id', 'name') VALUES ('${genre.genreID}', '${genre.genreName}');`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}

module.exports = {
  getGenres,
  getGenreByID,
  getGenreByName,
  deleteGenre,
  addGenre,
  getGenreByMovieID

}