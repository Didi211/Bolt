const db = require('../config/db.config')



const getWatchedLists = (result) => {
    db.query(`SELECT * FROM watched_lists`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
    })
} 
const getWatchedListById = (id,result) => {
    db.query(`SELECT * FROM watched_lists WHERE id = '${id}'`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
    })
}
const getWatchedListsByUserId = (id,result)=> {
    db.query(`SELECT * FROM watched_lists WHERE user_id = '${id}'`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
    })
}
const getWatchedListMoviesByListID = (id,result) =>{
    db.query(`SELECT * FROM movies WHERE id = ANY(SELECT movie_id from movies_watched_list WHERE watched_list_id = ${id})`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
    })
}
const deleteWatchedList = (id,result) =>{
    db.query(`DELETE FROM watched_lists WHERE id = ${id}`,(err,res)=>{
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        db.query(`DELETE FROM movies_watched_list WHERE watched_list_id = ${id}`,(err,res)=>{
            if (err) {
              console.log("error: ", err);
              result(null, err);
              return;
            }
          })
        result(null, res);
      })
}
const deleteWatchedLists = (id,result) => {
    db.query(`DELETE FROM watched_lists WHERE user_id = ${id}`,(err,res)=>{
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        db.query(`DELETE FROM movies_watched_list WHERE watched_list_id = ANY(SELECT id from watched_lists WHERE user_id = ${id})`,(err,res)=>{
            if (err) {
              console.log("error: ", err);
              result(null, err);
              return;
            }
            result(null, res);
          })
      })
}
const addMovieToWatchedList = (movie_id,list_id,result) => {
    db.query(`INSERT INTO movies_watched_list (watched_list_id, movie_id) VALUES ('${list_id}', '${movie_id}')`,(err,res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
      })
}
const removeMovieFromWatchedList = (movie_id,list_id,result) => {
    db.query(`DELETE FROM movies_watched_list WHERE watched_list_id = '${list_id}' AND  movie_id = '${movie_id}'`,(err,res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        
        result(null, res);
      })
}
const addWatchedList = (list,result) => {
    db.query(`INSERT INTO watched_lists (is_public, user_id) VALUES ('${list.public}', '${list.user_id}')`,(err,res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
      })
}
const alterWatchedList = (list,result) => {
    db.query(`UPDATE watched_lists SET is_public = '${list.public}' WHERE (user_id = '${list.user_id}')`,(err,res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
      })
}

module.exports = {
    getWatchedLists,
    getWatchedListById,
    getWatchedListsByUserId,
    getWatchedListMoviesByListID,
    deleteWatchedList,
    deleteWatchedLists,
    addMovieToWatchedList,
    removeMovieFromWatchedList,
    addWatchedList,
    alterWatchedList
  }