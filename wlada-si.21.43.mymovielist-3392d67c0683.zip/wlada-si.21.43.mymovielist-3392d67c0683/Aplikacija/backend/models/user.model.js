const db = require('../config/db.config')
const {deleteReviews} = require('./review.model')
const {deleteMylists} = require('./mylists.model')
const {deleteWatchedLists} = require('./watchedlist.model')


const getUsers = result => {
 db.query(`SELECT * FROM users`, (err, res) => {
   if (err) {
     console.log("error: ", err);
     result(null, err);
     return;
   }
   result(null, res);
 });
};
const getUserByID = (userID,result) => {
  db.query(`SELECT * FROM users WHERE id = "${userID}"`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
}
const getUserByUsername = (username,result) => {
  db.query(`SELECT * FROM users WHERE username = "${username}"` , (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
  
    result(null, res[0]);
  });
}
const getUserByEmail = (email,result) => {
    db.query(`SELECT * FROM users WHERE email = "${email}"` , (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      result(null, res);
    });
  }

const getUserByEmailOrUsername = (user,result) =>{
  db.query(`SELECT * FROM users WHERE username = '${user.username}' OR email = '${user.email}'`, (err,res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const addUser = (user, result) =>{
  db.query(`INSERT INTO users (username, password, email, role, firstname, lastname) VALUES ('${user.username}', '${user.password}','${user.email}','${user.role}','${user.firstname}','${user.lastname}')`,(err,res)=>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const alterUser = (userdata, id,result) =>{
    db.query(`UPDATE users SET password = '${userdata.password}', email = '${userdata.email}', bio = '${userdata.bio}', firstname = '${userdata.firstname}',lastname = '${userdata.lastname}' WHERE id = ${id} `,(err,res)=>{
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
      })
}
const alterBio = (bio, id,result) =>{
  db.query(`UPDATE users SET  bio = '${bio}' WHERE id = ${id} `,(err,res)=>{
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      result(null, res);
    })
}
//treba dodati brisanje svih njegovih informacija  reviewovi, liste ...
const deleteUser = (userID, result) =>{
  
  db.query(`DELETE FROM users WHERE id = ${userID}`,(err,res)=>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    deleteReviews(userID,(err,data)=>{
      if(err)
      {
        console.log(err);
        return
      }return
    })
    deleteMylists(userID,(err,data)=>{
      if(err)
      {
        console.log(err);
        return
      }return
    })
    deleteWatchedLists(userID,(err,data)=>{
      if(err)
      {
        console.log(err);
        return
      }return
    })
    result(null, res);
  })
}

const getUserByUsernameAndPassword = (user,result) => {
  db.query(`SELECT username, id, email,role FROM users WHERE username = "${user.username}" AND password = "${user.password}"` , (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
  
    result(null, res[0]);
  });
}
const alterUserName= (fistname,lastname,id,result) => {
  db.query(`UPDATE users SET  firstname = '${fistname}', lastname = '${lastname}' WHERE id = ${id} `,(err,res)=>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const alterUserEmail= (email,id,result) => {
  db.query(`UPDATE users SET  email = '${email}' WHERE id = ${id} `,(err,res)=>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const alterUserPassword= (password,id,result) => {
  db.query(`UPDATE users SET  password = '${password}' WHERE id = ${id} `,(err,res)=>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const setRoleToCM = (userID,result) => {
  console.log(userID);
  db.query(`UPDATE users SET role = 'cm' WHERE id = ${userID}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
}
const setRoleToMember= (userID,result) => {
  db.query(`UPDATE users SET role = 'member' WHERE id = ${userID}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
}
const addFollower = (user_id,targetUser_id,result) => {
  db.query(`INSERT INTO followers (follower_id, followed_id) VALUES ('${user_id}', '${targetUser_id}')`,(err,res)=>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const removeFollower = (user_id,targetUser_id,result) => {
  db.query(`DELETE FROM followers WHERE follower_id = ${user_id} AND followed_id = ${targetUser_id}`,(err,res)=>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const  showFollowing = (user_id,result) => {
  db.query(`SELECT * FROM followers WHERE follower_id = "${user_id}"`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
 }
const  showFollowers = (user_id,result) => {
  db.query(`SELECT * FROM followers WHERE followed_id = "${user_id}"`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
 }
module.exports = {
    getUsers,
    getUserByID,
    getUserByUsername,
    getUserByEmail,
    addUser,
    alterUser,
    alterBio,
    deleteUser,
    getUserByEmailOrUsername,
    getUserByUsernameAndPassword,
    alterUserName,
    alterUserEmail,
    alterUserPassword,
    setRoleToCM,
    setRoleToMember,
    addFollower,
    removeFollower,
    showFollowing,
    showFollowers
  }