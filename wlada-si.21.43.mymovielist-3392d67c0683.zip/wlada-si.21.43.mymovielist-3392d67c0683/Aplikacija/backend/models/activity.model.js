const db = require('../config/db.config')

const getActivityReviews = (user_id,result) => {
 db.query(`SELECT * FROM projekatsi.reviews WHERE user_id =ANY(SELECT followed_id FROM projekatsi.followers where follower_id = '${user_id}') ORDER BY date_time DESC LIMIT 0, 100`, (err, res) => {
   if (err) {
     console.log("error: ", err);
     result(null, err);
     return;
   }
   result(null, res);
 });
};

module.exports = {
    getActivityReviews
}