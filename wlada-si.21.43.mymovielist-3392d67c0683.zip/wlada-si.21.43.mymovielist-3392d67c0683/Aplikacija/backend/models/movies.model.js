const db = require('../config/db.config')

const getMovies = (result) => {
    db.query(`SELECT * FROM movies`, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      result(null, res);
    });
}
const getMovieByID = (id,result) => {
  db.query(`SELECT * FROM movies where id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  });
}
const getMoviesByGenre = (genre,result) => {
    db.query(`SELECT id from genres WHERE name = '${genre}'`, (err,res1) => {        
        if(err){
            console.log("error: ", err);
            result(null, err);
            return;
        }         
        let id = res1[0].id;  
        db.query(`SELECT * FROM movies WHERE id = ANY(SELECT movie_id from movies_genres WHERE genre_id = ${id})`,(err, res2) => {
            if (err) {
              console.log("error: ", err);
              result(null, err);
              return;
            }            
            result(null, res2);  
    })
    
})
}
const getMoviesByActorName = (actor_id,result) => { 
    db.query(`SELECT * FROM movies WHERE id = ANY(SELECT movie_id from crew_movies WHERE crew_name = '${actor_id}')`,(err, res2) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }            
        result(null, res2);  
})


}
const getMoviesPartialName = (input,result) => {
    db.query(`SELECT * from movies WHERE original_title LIKE '%${input}%'`,(err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      result(null, res);
    });
}
const addMovie = (movie,result) => {
  db.query(`INSERT INTO movies (id, original_title, backdrop_path, poster_path, release_date, overview, runtime, vote_average, watched, vote_count) VALUES ('${movie.id}', '${movie.original_title}', '${movie.backdrop_path}', '${movie.poster_path}', '${movie.release_date}', '${movie.overview}', '${movie.runtime}', '0000000000', '0000000000', '000000000')
  `, (err,res) =>{
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const updateMovie = (movie,result) => {
  db.query(`UPDATE movies SET original_title = '${movie.original_title}', backdrop_path = '${movie.backdrop_path}', poster_path = '${movie.poster_path}', release_date = '${movie.release_date}', overview = '${movie.overview}', runtime = '${movie.runtime}' WHERE (id = '${movie.id}')
  `, (err,res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    result(null, res);
  })
}
const deleteMovie = (movie,result) => {
  let errors = []
  let data = []
  db.query(`DELETE FROM movies WHERE id = ${movie}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      errors.push(err)
    }
    data.push(res)
    db.query(`DELETE FROM movies_genres WHERE movie_id = ${movie}`, (err, res) => {
      if (err) {
        console.log("error: ", err);
        errors.push(err)
      }
      data.push(res)
      db.query(`DELETE FROM movies_mylist WHERE movie_id = ${movie}`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          errors.push(err)
        }
        data.push(res)
        db.query(`DELETE FROM reviews WHERE movie_id = ${movie}`, (err, res) => {
          if (err) {
            console.log("error: ", err);
            errors.push(err)
            
          }
          data.push(res)
          db.query(`DELETE FROM crew_movies WHERE movie_id = ${movie}`, (err, res) => {
            if (err) {
              console.log("error: ", err);
              errors.push(err)
          
            }
            data.push(res)
            db.query(`DELETE FROM movies_watched_list WHERE movie_id = ${movie}`, (err, res) => {
              if (err) {
                console.log("error: ", err);
                errors.push(err)
                result(null,errors)
              }
              data.push(res)
              result(null,data)
            })
          })
        })
      })
    })
})



}
module.exports = 
{
    getMovies,
    getMovieByID,
    getMoviesByGenre,
    getMoviesPartialName,
    addMovie,
    updateMovie,
    getMoviesByActorName,
    deleteMovie
}