const db = require('../config/db.config')



const getMylists = (result) => {
    db.query(`SELECT * FROM mylists`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
    })
} 
const getMylistById = (id,result) => {
    db.query(`SELECT * FROM mylists WHERE id = '${id}'`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
    })
}
const getMylistsByUserId = (id,result)=> {
    db.query(`SELECT * FROM mylists WHERE user_id = (SELECT id FROM users WHERE username = '${id}')`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
    })
}
const getMylistsByUserIdPublic = (id,result)=> {
  db.query(`SELECT * FROM mylists WHERE user_id = '${id}' AND is_public = '1'`, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
      result(null, res);
  })
}
const getMylistMoviesByListID = (id,result) =>{
    db.query(`SELECT * FROM movies WHERE id = ANY(SELECT movie_id from movies_mylist WHERE list_id = ${id})`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
    })
}
const deleteMylist = (id,result) =>{
    db.query(`DELETE FROM mylists WHERE id = ${id}`,(err,res)=>{
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        db.query(`DELETE FROM movies_mylist WHERE list_id = ${id}`,(err,res)=>{
            if (err) {
              console.log("error: ", err);
              result(null, err);
              return;
            }
          })
        result(null, res);
      })
}
const deleteMylists = (id,result) => {
    db.query(`DELETE FROM mylists WHERE user_id = ${id}`,(err,res)=>{
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        db.query(`DELETE FROM movies_mylist WHERE list_id = ANY(SELECT id from mylists WHERE user_id = ${id})`,(err,res)=>{
            if (err) {
              console.log("error: ", err);
              result(null, err);
              return;
            }
            result(null, res);
          })
      })
}
const addMovieToMylist = (movie_id,list_id,result) => {
    db.query(`INSERT INTO movies_mylist (list_id, movie_id) VALUES ('${list_id}', '${movie_id}')`,(err,res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
      })
}
const removeMovieFromMyList = (movie_id,list_id,result) => {
    db.query(`DELETE FROM movies_mylist WHERE list_id = '${list_id}' AND  movie_id = '${movie_id}'`,(err,res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        
        result(null, res);
      })
}
const addMylist = (list,result) => {
    db.query(`INSERT INTO mylists (is_public, user_id, name, description) VALUES ('${list.public}', '${list.user_id}', '${list.name}', '${list.description}')`,(err,res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
      })
}
const alterMylist = (list,result) => {
    db.query(`UPDATE mylists SET is_public = '${list.public}', name = '${list.name}', description = '${list.description}' WHERE (id = '${list.id}')`,(err,res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
        result(null, res);
      })
}

module.exports = {
    getMylists,
    getMylistById,
    getMylistsByUserId,
    getMylistMoviesByListID,
    deleteMylist,
    deleteMylists,
    addMovieToMylist,
    removeMovieFromMyList,
    addMylist,
    alterMylist,
    getMylistsByUserIdPublic
  }