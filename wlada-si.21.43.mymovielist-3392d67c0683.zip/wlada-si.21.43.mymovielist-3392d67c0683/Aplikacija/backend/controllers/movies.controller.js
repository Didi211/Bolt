const { 
    getMovies,
    getMovieByID,
    getMoviesByGenre,
    getMoviesPartialName,
    addMovie,
    updateMovie,
    getMoviesByActorName,
    deleteMovie
} = require('../models/movies.model');

const showMovies = (req,res) => {
    getMovies((err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showMovieByID = (req,res) => {
    getMovieByID (req.body.movie_id,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showMoviesByGenre = (req,res) => {
    getMoviesByGenre (req.body.genre,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}

const showMoviesByActorName = (req,res) => {
    getMoviesByActorName (req.body.actor_name,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showMoviesPartialName = (req,res) => {
    getMoviesPartialName(req.body.input,(err,data) =>{
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const removeMovie = (req,res) => {
    deleteMovie(req.body.movie_id,(err,data)=> {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const createMovie = (req,res) => {
    let movie = {
        id : req.body.id,
        original_title : req.body.original_title ,
        backdrop_path : req.body.backdrop_path,
        poster_path : req.body.poster_path,
        release_date : req.body.release_date,
        overview : req.body.overview,
        runtime : req.body.runtime
    }
    addMovie(movie,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const alterMovie = (req,res) => {
    let movie = {
        id : req.body.id,
        original_title : req.body.original_title ,
        backdrop_path : req.body.backdrop_path,
        poster_path : req.body.poster_path,
        release_date : req.body.release_date,
        overview : req.body.overview,
        runtime : req.body.runtime
    }
    updateMovie(movie,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
module.exports = {
    showMovies,
    showMoviesByGenre,
    showMovieByID,
    showMoviesPartialName,
    createMovie,
    alterMovie,
    showMoviesByActorName,
    removeMovie
}