const {getTokenID} = require('../config/token')


const { 
    getReviews,
    getReviewsByID,
    addReview,
    updateReview,
    deleteReview,
    getReviewsByUserID,
    getReviewsByMovieID,
    deleteReviews
} = require('../models/review.model');

const showReviews = (req,res) => {
    getReviews((err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showReviewsById = (req,res) => {
    getReviewsByID (req.body.review_id,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}

const showReviewsByUserID = (req,res) => {
    getReviewsByUserID (req.body.user_id,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showReviewsByMovieID = (req,res) => {
     getReviewsByMovieID (req.body.movie_id,(err,data) => {
     if(err){
             res.send(err).status(500)
         }else{
             res.send(data).status(200)
         }
     })
}
const createReview = (req,res) => {
    let movie = {
        id : req.body.movie_id,
        vote_count: req.body.vote_count,
        vote_average: req.body.vote_average
    }
    let review = {
        rating : req.body.rating,
        description : req.body.description,
    }       
    let user = req.body.user_id //user je setovan u autentikaciji
    addReview(movie,user,review,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const alterReview = (req,res) => {
    let review = {
        id : req.body.review_id,
        user_id: req.body.user_id,
        movie_id : req.body.movie_id,
        rating : req.body.rating,
        old_rating : req.body.old_rating,
        description : req.body.description,
    }    
    updateReview(review, (err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const removeReview = (req,res) => {
    let review = {
        id : req.body.review_id,
        user_id: req.body.user_id,
        movie_id : req.body.movie_id,
        rating : req.body.rating,
    }
    deleteReview(review, (err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const removeReviews = (req,res) => {
    deleteReviews(req.body.user_id, (err,data)=>{
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
 
module.exports = {
    showReviews,
    showReviewsById,
    createReview,
    alterReview,
    removeReview,
    showReviewsByUserID,
    showReviewsByMovieID,
    removeReviews
}