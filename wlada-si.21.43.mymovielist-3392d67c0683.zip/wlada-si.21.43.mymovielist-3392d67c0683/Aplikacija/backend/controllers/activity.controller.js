const { getActivityReviews,
} = require('../models/activity.model');


const showActivityReviews = (req,res) =>{    
    getActivityReviews(req.body.user_id, (err,data) =>{
        if(err){
            res.send(err)
        }
        else{
            if(data != ''){
               res.send(data).status(200)
        }else
            res.status(200).send({
                message: "No recent reviews"})
        }
    })
}

module.exports = {
    showActivityReviews
}