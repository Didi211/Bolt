const { getActors,
        getActorByName,
        getActorsByMovieID,
        addActor,
        deleteActor
    } = require('../models/actor.model');

const showActors = (req,res) => {
    getActors ((err,data) => {
        if(err){
            res.send(err)
        }else{
            if(data != ''){
               res.send(data).status(200)
        }else
            res.status(404).send("Not found")
        }
    }
)
}
const showActorByName = (req,res) =>{    
    getActorByName(req.body.actorID, (err,data) =>{
        if(err){
            res.send(err)
        }
        else{
            if(data != ''){
               res.send(data).status(200)
        }else
            res.status(404).send("Not found")
        }
    })
}
const showActorsByMovieID = (req,res)  =>{
    getActorsByMovieID(req.body.movieID, (err,data) =>{
        if(err){
            res.send(err)
        }
        else{
            if(data != ''){
               res.send(data).status(200)
            }else
            res.status(404).send("Not found")
        }
    })
}
const createActor = (req,res) => {
    let actor= {
        movieID : req.body.movieID,
        actorName: req.body.actorName,

    }   
    addActor(actor,(err,data)=>{
        if(err){
            res.send(err).status(500)
        }
        else{
            res.send(data).status(200)
        }
    })
}
const removeActor = (req,res) => {
    let actor= {
        movieID : req.body.movieID,
        actorName: req.body.actorName,
    }
    deleteActor(actor,(err,data)=>{
        if(err){
            res.send(err).status(500)
        }
        else{
            res.send(data).status(200)
        }
    })
}

module.exports = {
    showActors,
    showActorByName,
    showActorsByMovieID,
    createActor,
    removeActor
}
