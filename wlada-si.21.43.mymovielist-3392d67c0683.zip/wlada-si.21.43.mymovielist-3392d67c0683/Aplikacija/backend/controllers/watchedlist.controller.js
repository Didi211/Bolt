const {  getWatchedLists,
    getWatchedListById,
    getWatchedListsByUserId,
    getWatchedListMoviesByListID,
    deleteWatchedList,
    deleteWatchedLists,
    addMovieToWatchedList,
    removeMovieFromWatchedList,
    addWatchedList,
    alterWatchedList
} = require('../models/watchedlist.model');
 



const showWatchedlists = (req,res) => {
    getWatchedLists ((err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
const showWatchedListById = (req,res) => {
    getWatchedListById (req.body.list_id,(err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
const showWatchedListsByUserId = (req,res) => {
    getWatchedListsByUserId (req.body.target_user_id,(err,data) => {
        if(err){
            res.send(err).status(500)
         }else{
            res.send(data).status(200)
        }
   })
}
const showWatchedListMoviesByListID = (req,res) => {
    getWatchedListMoviesByListID (req.body.list_id,(err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
const removeWatchedList = (req,res) => {
    deleteWatchedList (req.body.list_id,(err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
const removeWatchedLists = (req,res) => {
    deleteWatchedLists (req.body.DELETEuser_id,(err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
const deleteMovieFromWatchedList = (req,res) => {
    removeMovieFromWatchedList (req.body.movie_id,req.body.list_id,(err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
const addNewMovieToWatchedList = (req,res) => {
    addMovieToWatchedList (req.body.movie_id,req.body.list_id,(err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
const createWatchedList = (req,res) => {
    list = {
        public: 0,
        user_id: req.body.user_id,        
    }

    addWatchedList (list,(err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
const updateWatchedList = (req,res) => {
    list = {
        public: req.body.public,
        user_id: req.body.user_id,        
    }

    alterWatchedList (list,(err,data) => {
    if(err){
        res.send(err).status(500)
     }else{
        res.send(data).status(200)
    }
   })
}
module.exports = {
    showWatchedlists,
    showWatchedListById,
    showWatchedListsByUserId,
    showWatchedListMoviesByListID,
    removeWatchedList,
    removeWatchedLists,
    deleteMovieFromWatchedList,
    addNewMovieToWatchedList,
    createWatchedList,
    updateWatchedList
}