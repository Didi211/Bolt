const { getUsers,
    getUserByID,
    getUserByUsername,
    getUserByEmail,
    addUser,
    deleteUser,
    alterUserName,
    alterUserEmail,
    alterUserPassword,
    getUserByEmailOrUsername,
    alterBio,
    setRoleToMember,
    setRoleToCM,
    addFollower,
    removeFollower,
    showFollowing,
    showFollowers
} = require('../models/user.model');

const bcrypt = require('bcrypt');
const saltRounds = 10;


const  token = require('../config/token')
const jwt = require('jsonwebtoken')

const showUsers = (req,res) => {
     getUsers ((err,data) => {
     if(err){
         res.send(err).status(500)
      }else{
         res.send(data).status(200)
     }
    })
}
const showUserByID = (req,res) =>{    
    getUserByID(req.body.user_id, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){
           res.send(data).status(200)
    }else
        res.status(404).send("Not found")
    }
      
})
}
const showLoggedUserByID = (req,res) =>{    
    getUserByID(req.body.user_id, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){
            res.send(data).status(200)
        }else
            res.status(404).send("Not found")
    }
      
})
}
const showUsersByEmail = (req,res)  =>{
    getUserByEmail(req.body.email, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){
            res.send(data).status(200)
        }else
            res.status(404).send("Not found")
    }
})
}
const showUsersByUsername = (req,res)  =>{
    getUserByUsername(req.body.username, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data){
            res.send(data).status(200)
        }else
            res.status(404).send("User not found")
    }
})
}
const createUser = (req,res) => {
    bcrypt.hash(req.body.password, saltRounds, function(err, hash) {
        let user= {     
            username : req.body.username,
            password :hash,
            email :req.body.email,
            role: req.body.role,
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            bio :"",
        }
        getUserByEmailOrUsername(user, (err,data)=>{
            if(err){
                res.send(err).status(500)
            }
            else{
                if(data == ''){
                    
                    addUser(user,(err,data)=>{
                        if(err){
                            res.status(400).send(err)
                        }
                        else{                        
                            res.send({user: user}).status(200)
                        }
                    }) 
                   
                }else{
                    res.status(400).send(err)
                }
            }
        })
    });
    
}

const updateUserBio = (req,res) =>{
        alterBio(req.body.bio, req.body.id,(err,data)=>{
            if(err){
                res.send(err)
            }
            else{
                if(data != [])
                res.send(data).status(200)
                else
                res.status(404).send("Not found") 
            }
        })    
}
const updateUserEmail = (req,res) => {
    getUserByEmail(req.body.newEmail,(err,data)=>{
        if(err){
            res.send(err)
        }else{
            if(data == '')
            alterUserEmail(req.body.newEmail,req.body.user_id,(err,data)=>{
                if(err){
                    res.send(err)
                }
                else{
                    if(data == '')
                    res.send(data).status(200)
                    else
                    res.status(404).send("Not found")
                }   
            })
            else
            res.status(406).send("Email is in use already")
        }
    })
    

}
const updateUserPassword = (req,res) => {

    getUserByID(req.body.user_id, (err,data) =>{
        if(err){
            res.send(err).status(500)
        }
        else{
            if(data != ''){
               var user = data[0]
               bcrypt.compare(req.body.oldPassword, user.password, function(err, result) {
                if(result){
                    bcrypt.hash(req.body.newPassword, saltRounds, function(err, hash) {
                        alterUserPassword(hash, req.body.user_id,(err,data)=>{
                            if(err){
                                res.send(err)
                            }
                            else{
                                if(data != [])
                                res.send(data).status(200)
                                else
                                res.status(404).send("Not found") 
                            }
                        })
                    });
                    return;
                }else{
                    res.send("Incorrect old password").status(401)
                }
            })
        }else
            res.status(404).send("Not found")
        }
    })
    
    
}
const updateUserName = (req,res) =>{

        alterUserName(req.body.firstname,req.body.lastname, req.body.user_id,(err,data)=>{
            if(err){
                res.send(err)
            }
            else{
                if(data != [])
                res.send(data).status(200)
                else
                res.status(404).send("Not found") 
            }
        })

    
}

    
const demoteUserToMember = (req,res) =>{
    setRoleToMember(req.body.user_id,(err,data)=>{
        if(err){
            res.send(err)
        }
        else{
            if(data != [])
            res.send(data).status(200)
            else
            res.status(404).send("Not found") 
        }
    })


}
const promoteUserToCM = (req,res) =>{
        setRoleToCM(req.body.user_id,(err,data)=>{
            if(err){
                res.send(err)
            }
            else{
                if(data != [])
                res.send(data).status(200)
                else
                res.status(404).send("Not found") 
            }
        })

    
}
const removeUser = (req,res) => {  
    deleteUser(req.body.id,(err,data)=>{
        if(err){
            res.send(err)
        }
        else{
            if(data != [])
            res.send(data).status(200)
            else
            res.status(404).send("Not found")
    }
})
}
const follow = (req,res) => {
    addFollower(req.body.user_id,req.body.targetUser_id,(err,data)=>{
        if(err){
            res.send(err)
        }
        else{
            if(data != [])
            res.send(data).status(200)
            else
            res.status(404).send("Not found")
    }
    })
}
const unfollow = (req,res) => {
    removeFollower(req.body.user_id,req.body.targetUser_id,(err,data)=>{
        if(err){
            res.send(err)
        }
        else{
            if(data != [])
            res.send(data).status(200)
            else
            res.status(404).send("Not found")
    }
    })
}
const following = (req,res) => {
    showFollowing(req.body.user_id,(err,data)=>{
        if(err){
            res.send(err)
        }
        else{
            if(data != [])
            res.send(data).status(200)
            else
            res.status(404).send("Not found")
    }
    })
}
const followers = (req,res) => {
    showFollowers(req.body.user_id,(err,data)=>{
        if(err){
            res.send(err)
        }
        else{
            if(data != [])
            res.send(data).status(200)
            else
            res.status(404).send("Not found")
    }
    })
}

module.exports = {
    showUsers,
    showUserByID,
    showUsersByUsername,
    showUsersByEmail,
    createUser,
 //   updateUser,
    updateUserPassword,
    updateUserName,
    updateUserEmail,
    removeUser,
    showLoggedUserByID,
    updateUserBio,
    demoteUserToMember,
    promoteUserToCM,
    follow,
    unfollow,
    following,
    followers
}
