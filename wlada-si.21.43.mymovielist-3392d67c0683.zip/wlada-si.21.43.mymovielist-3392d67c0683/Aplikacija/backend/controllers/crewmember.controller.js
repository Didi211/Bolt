const { getCrewmember,
    getCrewmemberByName,
    getCrewmemberByMovieID,
    addCrewmember,
    deleteCrewmember
} = require('../models/crewmember.model');

const showCrewmembers = (req,res) => {
    getCrewmember ((err,data) => {
    if(err){
        res.send(err).status(500)
    }else{
        if(data != ''){
           res.send(data).status(200)
    }else
        res.status(404).send("Not found")
    }
}
)}

const showCrewmemberByName = (req,res) =>{    
    getCrewmemberByName(req.body.crewmemberName, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){
           res.send(data).status(200)
    }else
        res.status(404).send("Not found")
    }
})
}
const showCrewmembersByMovieID = (req,res)  =>{
    getCrewmemberByMovieID(req.body.movie_id, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){
           res.send(data).status(200)
    }else
        res.status(404).send("Not found")
    }
})
}

const createCrewmember = (req,res) => {
    let crewmember= {
        movieID : req.body.movie_id,
        crewmemberName: req.body.crewmemberName,
        role: req.body.role,    
    }
    addCrewmember(crewmember,(err,data)=>{
    if(err){
        res.send(err).status(500)
    }
    else{
        res.send(data).status(200)
    }
})
}
const removeCrewmember = (req,res) => {
    let crewmember= {
        movieID : req.body.movie_id,
        crewmemberName: req.body.crewmemberName,
        role: req.body.role,
    }
    deleteCrewmember(crewmember,(err,data)=>{
        if(err){
            res.send(err).status(500)
        }
        else{
            res.send(data).status(200)    
        }
})
}

module.exports = {
showCrewmembers,
showCrewmemberByName,
showCrewmembersByMovieID,
createCrewmember,
removeCrewmember
}
