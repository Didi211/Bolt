const { getGenres,
    getGenreByID,
    getGenreByName,
    deleteGenre,
    addGenre,
    getGenreByMovieID
} = require('../models/genre.model');
const { get } = require('../routes/movies');


const showGenres = (req,res) => {
      getGenres ((err,data) => {
      if(err){
          res.send(err).status(500)
      }else{
          res.send(data).status(200)
      }
    }
)
}
const showGenreByID = (req,res) =>{    
    getGenreByID(req.body.genre_id, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){           
           res.send(data).status(200)           
        }else
        res.status(404).send("Not found")
    }
      
})
}
const showGenreByMovieID = (req,res) =>{    
    getGenreByMovieID(req.body.movie_id, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){           
           res.send(data).status(200)           
        }else
        res.status(404).send("Not found")
    }
      
})
}
const showGenreByName = (req,res)  =>{
    getGenreByName(req.body.genreName, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){
            res.send(data).status(200)
        }else
            res.status(404).send("Not found")
    }
})
}
const removeGenre = (req,res) =>{    
    deleteGenre(req.body.genre_id, (err,data) =>{
    if(err){
        res.send(err).status(500)
    }
    else{
        if(data != ''){
           res.send(data).status(200)
    }else
        res.status(404).send("Not found")
    }
      
})
}
const createGenre = (req,res) => {
    let genre= {     
        name : req.body.genreName,
        id : req.body.genre_id,        
    }
    addGenre(genre,(err,data)=>{
    if(err){
        res.send(err).status(500)
    }
    else{
        res.send(data).status(200)
    }
})
}

module.exports = {
    showGenres,
    showGenreByID,
    showGenreByName,
    removeGenre,
    createGenre,
    showGenreByMovieID

}