const { getMylists,
    getMylistById,
    getMylistsByUserId,
    getMylistMoviesByListID,
    deleteMylist,
    deleteMylists,
    addMovieToMylist,
    removeMovieFromMyList,
    addMylist,
    alterMylist,
    getMylistsByUserIdPublic
} = require('../models/mylists.model');

const showMylists = (req,res) => {
    getMylists((err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showMylistById = (req,res) => {
    getMylistById(req.body.list_id,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showMylistsByUserId = (req,res) => {
    getMylistsByUserId(req.body.user_id,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showMylistsByUserIdParams = (req,res) => {
    getMylistsByUserId(req.params.userID,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showMylistsByUserIdPublic = (req,res) => {
    getMylistsByUserIdPublic(req.body.publicUser_id,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const showMylistMoviesByListID = (req,res) => {
    getMylistMoviesByListID(req.body.list_id,(err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const removeMylist = (req,res) => {
    deleteMylist(req.body.list_id, (err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const removeMylists = (req,res) => {
    deleteMylists(req.body.DELETEuser_id, (err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const addNewMovieToMylist = (req,res) => {
    addMovieToMylist(req.body.movie_id,req.body.list_id, (err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const deleteMovieFromMylist = (req,res) => {
    removeMovieFromMyList(req.body.movie_id,req.body.list_id, (err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const createMylist = (req,res) => {
    let list = {
        public : req.body.public,
        user_id : req.body.user_id,
        name : req.body.name,
        description : req.body.description
    }
    addMylist(list, (err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}
const updateMylist = (req,res) => {
    let list = {
        id : req.body.list_id,
        public : req.body.public,
        name : req.body.name,
        description : req.body.description
    }
    alterMylist(list, (err,data) => {
        if(err){
            res.send(err).status(500)
        }else{
            res.send(data).status(200)
        }
    })
}

module.exports = {
    showMylists,
    showMylistById,
    showMylistsByUserId,
    showMylistMoviesByListID,
    removeMylist,
    removeMylists,
    addNewMovieToMylist,
    deleteMovieFromMylist,
    createMylist,
    updateMylist,
    showMylistsByUserIdPublic,
    showMylistsByUserIdParams
}
