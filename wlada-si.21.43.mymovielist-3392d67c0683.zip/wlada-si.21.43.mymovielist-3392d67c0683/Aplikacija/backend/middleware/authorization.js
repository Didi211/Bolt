const jwt = require('jsonwebtoken')
const {getTokenRole} = require('../config/token')


const authAdmin = (req,res,next) =>{

    if(req.headers["authorization"] != ""){
        try{
            const userRole = getTokenRole(req)
            console.log(userRole);
            if(userRole !== "admin"){
                res.send(401,"not allowed")
            }
            else 
            next();
        }catch (e){
            res.status(401).send("token error")
        }
    }else{
        res.status(401).send("data missing")
    }
}
module.exports = authAdmin
