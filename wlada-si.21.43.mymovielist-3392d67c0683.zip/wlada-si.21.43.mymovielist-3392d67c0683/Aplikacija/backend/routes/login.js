 const express = require('express')
 const router = express.Router()

const {getUserByUsernameAndPassword, getUserByUsername} = require('../models/user.model')

//const {auth} = require('../middleware/authorization')

const token = require('../config/token')
const bcrypt = require('bcrypt')

router.post('/',(req,res)=>{
    getUserByUsername(req.body.username, (err,data) => {
        var user = data
        if(user) {            
            bcrypt.compare(req.body.password, user.password, function(err, result) {
                if(result){
                    var currentToken = token.generateAccessToken(user)
                    res.send({user: user, token: currentToken});
                    return;
                }else{
                    res.status(401).send({
                        error: "Incorrect password"})
                }
            })
        }else{
            res.status(404).send({
                error: "User not found"})
        }
    })
    // getUserByUsernameAndPassword({username: req.body.username, password:req.body.password}, (err,data) => {
    //     var user = data
    //     if (user) {
    //         var currentToken = token.generateAccessToken(user)
    //         res.send({user: user, token: currentToken});
    //         return;
    //     }
    //     res.status(401).send('error')
    // })
})

module.exports = router