const express = require("express")
const router = express.Router()

//const auth = require('../middleware/authentication')

const {showGenres,
    showGenreByID,
    showGenreByName,
    removeGenre,
    createGenre,
    showGenreByMovieID
} = require('../controllers/genre.controller')

router.get('/',showGenres)                  //vraca sve zanrove
router.post('/genreID',showGenreByID)        //vraca zanr na osnovu id-a u body.genre_id
router.post('/name/',showGenreByName)        //vraca zanr na osnovu imena
router.post('/movieID',showGenreByMovieID)   //vraca zanr na osnovu id-a filma body.movie_id

router.post('/',createGenre)                //kreira novi zanr na osnovu body.genreName body.genre_id

router.delete('/',removeGenre)              //brise zanr na osonvu body.genre_id

module.exports = router