const express = require("express")
const router = express.Router()

const { showActivityReviews,
} = require('../controllers/activity.controller');

const auth = require('../middleware/authentication')


router.get('/',auth,showActivityReviews)

module.exports = router