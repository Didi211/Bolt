 const express = require("express")
const router = express.Router()

const auth = require('../middleware/authentication')

const {
    showReviews,
    showReviewsById,
    createReview,
    alterReview,
    removeReview,
    showReviewsByUserID,
    showReviewsByMovieID,
    removeReviews
} = require('../controllers/review.controller')


router.get('/',showReviews)                     //prikazuje sve reviewove
router.get('/userId',auth,showReviewsByUserID)  //prikazuje reviove ulogovanog usera

router.post('/id',showReviewsById)               //prikazuje review sa id-em koji ja zadat u body.review_id
router.post('/movieId',showReviewsByMovieID)     //prikazuje reviewove za film sa id-em koji ja zadat u body.movie_id

router.post('/',auth,createReview)              //kreira (user koji kreira se dobija iz autentikacije)review cije se informacije nalaze u body.movie_id,body.vote_count,body.vote_average,body.rating,body.description,

router.put('/',alterReview)                     //updatuje se review sa informacijama body.review_id,body.movie_id,body.rating,body.old_rating,body.description, NOTE!! mora da se prosledi i rating koji je vec bio setovan

router.delete('/',removeReview)                 //brise se review sa id-em koji ja zadat u body.review_id
router.delete('/userID',removeReviews)

router
module.exports = router