const express = require("express")
const router = express.Router()

const auth = require('../middleware/authentication')

const {showMylists,
    showMylistById,
    showMylistsByUserId,
    showMylistMoviesByListID,
    removeMylist,
    removeMylists,
    addNewMovieToMylist,
    deleteMovieFromMylist,
    createMylist,
    updateMylist,
    showMylistsByUserIdPublic,
    showMylistsByUserIdParams
} = require('../controllers/mylist.controller')

router.get('/',showMylists)                              //vraca sve licne liste
router.get('/userID',auth,showMylistsByUserId)           //vraca sve licne liste ulogovanog usera
router.get('/:userID',showMylistsByUserIdParams)
router.post('/listID',showMylistById)                     //vraca listu sa id-em u body.list_id
router.post('/userID/public',showMylistsByUserIdPublic)   //vraca javne liste usera sa id-em u body.publicUser_id
router.post('/movies',showMylistMoviesByListID)      //vraca sve filmove koji se nalaze u zadatoj listi body.list_id

router.post('/',createMylist)                       //kreira se nova lista sa parametrima body.public,body.user_id,body.name,body.description (body.public je 0 ili 1 gde se za jedan smatra kao javna lisa dok za 0 kao privatna)
router.post('/addMovie',addNewMovieToMylist)        //dodavanje filma u listu gde su id filma i id liste body.movie_id body.list_id

router.delete('/removeMovie',deleteMovieFromMylist) //brisanje filma iz liste gde su id filma i id liste body.movie_id body.list_id
router.delete('/',removeMylist)                     //bise listu sa id-em body.list_id
router.delete('/userID',removeMylists)              //bise sve liste usera sa id-em body.DELETEuser_id

router.put('/',updateMylist)                        //updatuje listu sa zadatim id-em i parametriam body.list_id,body.public,body.name,body.description (body.public je 0 ili 1 gde se za jedan smatra kao javna lisa dok za 0 kao privatna)

module.exports = router