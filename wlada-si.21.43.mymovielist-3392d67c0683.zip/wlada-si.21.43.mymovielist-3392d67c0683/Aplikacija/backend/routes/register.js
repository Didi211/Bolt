const express = require('express')
const router = express.Router()

const {getUserByEmailOrUsername,addUser} = require('../models/user.model')
const token = require('../config/token')

const bcrypt = require('bcrypt');
const saltRounds = 10;


router.post('/',(req,res)=>{     

    bcrypt.hash(req.body.password, saltRounds, function(err, hash) {
        let user= {     
            username : req.body.username,
            password :hash,
            email :req.body.email,
            bio :"",
            role: "member",
            firstname: req.body.firstname,
            lastname: req.body.lastname
         }
         getUserByEmailOrUsername(user, (err,data)=>{
            if(err){
                res.send(err).status(500)
            }
            else{
                console.log(data);
                if(data == ''){
                    webtoken = token.generateAccessToken(user)
                    addUser(user,(err,data)=>{
                        if(err){
                            res.status(400).send({
                                error: "Please make sure no necessary fields are empty"
                            })
                        }
                        else{                        
                            res.send({user: user, token: webtoken}).status(200)
                        }
                    }) 
                   
                }else{
                    res.status(400).send({
                        error: "Email or username already exists!"})
                }
            }
        })
    })     
})

module.exports = router