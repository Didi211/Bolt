const express = require("express")
const router = express.Router()

const {showActors,
    showActorByName,
    showActorsByMovieID,
    createActor,
    removeActor
} = require('../controllers/actor.controller')

router.get('/',showActors)                      //prikazuje sve glumce
router.post('/actorID',showActorByName)          //prikazuje glumca sa imenom koje se nalazi u body.actorName
router.post('/movie/',showActorsByMovieID)       //prikazuje glumce na osnovu movie id-a koji se nalazi u body.movie_id

router.post('/',createActor)                    //kreira glumca na osnovu id-a filma i imena glumca u body.movie_id i body.actorName

router.delete('/',removeActor)                  //brise glumca na osnovu id-a filma i imena glumca u body.movie_id i body.actorName

module.exports = router