const express = require("express")
const router = express.Router()

const auth = require('../middleware/authentication')
const authAdmin = require('../middleware/authorization')

const {showUsers,
    showUserByID,
    showUsersByUsername,
    showUsersByEmail,
    createUser,
 //   updateUser,
    updateUserPassword,
    updateUserName,
    updateUserEmail,
    removeUser,
    showLoggedUserByID,
    updateUserBio ,
    demoteUserToMember,
    promoteUserToCM,
    follow,
    unfollow,
    following,
    followers

} = require('../controllers/user.controller')

router.get('/',showUsers)                           //vraca sve usere koji postoje
router.get('/getLoggedUser',auth,showLoggedUserByID)//vraca ulogovanog usera
router.post('/followers',followers)                  //na osnovu user_id vraca 
router.post('/following',following)

router.post('/userID',showUserByID)                  //vraca usera sa zadatim id-om u body.user_id
router.post('/username/',showUsersByUsername)        //vraca usera sa zadatim username-om u body.username     
router.post('/email/',showUsersByEmail)              //vraca usera sa zadatim email-om u body.email     

router.post('/',authAdmin,createUser)               //ADMIN kreira novog usera u body requesta treba da se nalaze body.username, body.password,body.email,body.role,body.firstname,body.lastname
router.post('/follow',follow)                       //body.user_id follows body.targetUser_id 
router.post('/unfollow',unfollow)                   //body.user_id unfollows body.targetUser_id 

router.put('/password',updateUserPassword)                          //update usera u body requesta treba da se nalaze  body.user_id body.newPassword,body.oldPassword
router.put('/bio',updateUserBio)                    //update bio usera body.bio body.id
router.put('/email',updateUserEmail)                //update email body.user_id body.newEmail
router.put('/name',updateUserName)                  //update name and lastname  body.firstname body.lastname body.user_id
router.put('/promote',authAdmin,promoteUserToCM)    //update role usera body.user_id u cm
router.put('/demote',authAdmin,demoteUserToMember)  //update role usera body.user_id u membera         

router.delete('/',removeUser)                       //brise se user za id-em koji se nalazi u body.id

module.exports = router