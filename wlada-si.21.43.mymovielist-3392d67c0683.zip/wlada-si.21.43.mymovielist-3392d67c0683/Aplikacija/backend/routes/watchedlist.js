const express = require("express")
const router = express.Router()

//const auth = require('../middleware/authentication')

const {showWatchedlists,
    showWatchedListById,
    showWatchedListsByUserId,
    showWatchedListMoviesByListID,
    removeWatchedList,
    removeWatchedLists,
    deleteMovieFromWatchedList,
    addNewMovieToWatchedList,
    createWatchedList,
    updateWatchedList
} = require('../controllers/watchedlist.controller')

router.get('/',showWatchedlists)                        //vraca sve wateched liste
router.post('/listID',showWatchedListById)               //vraca listu sa id-em body.list_id
router.post('/userID',showWatchedListsByUserId)          //vraca watched listu targetovanog usera body.target_user_id body.user_id(onaj ko salje zahtev)
router.post('/movies',showWatchedListMoviesByListID)     //vraca filmove zadate liste body.list_id

router.post('/',createWatchedList)                      //pravi novu listu ovo treba da se pozove kada se user registruje i da se prosledi body.user_id default se lista namesta na private
router.post('/addMovie',addNewMovieToWatchedList)       //dodavanje filma u listu potrebni us id filma i id liste body.movie_id body.list_id

router.delete('/removeMovie',deleteMovieFromWatchedList)//brisanje filma iz liste potrebni us id filma i id liste body.movie_id body.list_id
router.delete('/',removeWatchedList)                    //brisanje liste preko id-a body.list_id
router.delete('/userID',removeWatchedLists)             //brisnje liste preko user id-a body.user_id

router.put('/',updateWatchedList)                       //alterovanje javnosti liste body.public se setuje na 0 ili 1 (0 privatna lista, 1 javna lista)

module.exports = router