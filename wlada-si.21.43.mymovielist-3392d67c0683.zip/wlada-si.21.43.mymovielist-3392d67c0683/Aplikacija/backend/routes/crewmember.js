const express = require("express")
const router = express.Router()

const {showCrewmembers,
    showCrewmemberByName,
    showCrewmembersByMovieID,
    createCrewmember,
    removeCrewmember
} = require('../controllers/Crewmember.controller')

router.get('/',showCrewmembers)                         //prikazuje sve glumce             
router.post('/crewmemberName',showCrewmemberByName)      //prikazuje crewmemebere na osnovu imena u body.crewmemberName
router.post('/movie/',showCrewmembersByMovieID)          //prikazuje crewmemebere zadatog filma u body.movie_id

router.post('/',createCrewmember)                       //kreira novog crewmembera na osnovu body.movie_id body.crewmemberName body.role

router.delete('/',removeCrewmember)                     //brise crewmembera na osnovu body.movie_id body.crewmemberName body.role

module.exports = router