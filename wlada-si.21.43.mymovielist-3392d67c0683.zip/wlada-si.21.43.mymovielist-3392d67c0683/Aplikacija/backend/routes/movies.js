const express = require("express")
const router = express.Router()

const {
    showMovies,
    showMoviesByGenre,
    showMovieByID,
    showMoviesPartialName,
    createMovie,
    alterMovie,
    showMoviesByActorName,
    removeMovie
} = require('../controllers/movies.controller')


router.get('/',showMovies)                          //vraca sve filmove
router.post('/genre',showMoviesByGenre)              //vraca sve filmove ciji je zanr(ime zanra) zadat u body.genre
router.post('/partialname',showMoviesPartialName)    //vraca sve filmove koji sadrze body.input u imenu
router.post('/movieID',showMovieByID)                //vraca film koji imaa id zadat u movie_id
router.post('/actor',showMoviesByActorName)         //vraca filmove na osnovu body.actor_name
router.post('/',createMovie)                        //kreira film ciji se parametri nalaze u body.id,body.original_title ,body.backdrop_path,body.poster_path,body.release_date,body.overview,body.runtime

router.put('/',alterMovie)                          //alteruje film ciji se parametri nalaze u body.id,body.original_title ,body.backdrop_path,body.poster_path,body.release_date,body.overview,body.runtime

router.delete('/',removeMovie)                      //movie_id se parsjue u body

module.exports = router