const express = require("express")
const cors = require("cors")
const jwt = require("jsonwebtoken")

const actors = require('./routes/actor')
const crew = require('./routes/crewmember')
const users = require('./routes/user')
const genres = require('./routes/genre')
const movies = require('./routes/movies')
const login = require('./routes/login')
const register = require('./routes/register')
const reviews = require('./routes/review')
const mylist = require('./routes/mylists')
const watchedlist = require ('./routes/watchedlist')
const activity = require('./routes/activity')
const {auth} = require('./middleware/authentication')

const app = express()

app.use(cors())
app.use(express.json())
app.use(express.urlencoded({extended : false}))

app.use('/api/actor',actors)
app.use('/api/crewmember',crew)
app.use('/api/user',users)
app.use('/api/genre',genres) 
app.use('/api/movie',movies)
app.use('/api/review',reviews)
app.use('/api/mylist',mylist)
app.use('/api/watchedlist',watchedlist)
app.use('/api/activity', activity)

app.use('/register',register)
app.use('/login',login)

app.listen(5000,() => {
    console.log('Server is listening on port 5000....')
})

