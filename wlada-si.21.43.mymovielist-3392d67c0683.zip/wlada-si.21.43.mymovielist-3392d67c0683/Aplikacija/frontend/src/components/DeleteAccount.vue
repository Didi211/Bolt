<template>
  <div>
    <b-button variant="danger" v-b-modal.modal-sm
      ><b-icon icon="exclamation-triangle-fill"></b-icon> Delete
      Account</b-button
    >
    <b-modal id="modal-sm" ref="modal" title="Change Password" @ok="handleOk"
      ><h2>Are you sure you want to delete your account?</h2>
      <h5>
        By deleting your account all your lists and reviews will be deleted too.
      </h5>
      <!-- <h5>Page will refresh after changes.</h5> -->
    </b-modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import axios from "axios";
export default {
  name: "DeleteAccount",

  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
  methods: {
    handleOk() {
      this.deleteWatched(this.user[0].id);
      this.deleteLists(this.user[0].id);
      this.deleteReviews(this.user[0].id);
      this.deleteUser(this.user[0].id);
      this.$router.replace({ name: "Login" });
        localStorage.removeItem("token");
    },
    deleteUser(u) {
      axios
        .delete("http://localhost:5000/api/user/", {
          data: { id: u },
        })
        .then((response) => {
          console.log(response);
        })
        .catch(err => {
        console.error(err) 
      })
    },
    deleteWatched(u) {
      axios
        .delete("http://localhost:5000/api/watchedlist/userID", {
          data: { DELETEuser_id: u },
        })
        .then((response) => {
          console.log(response);
        })
        .catch(err => {
        console.error(err)
      })
    },
    deleteReviews(u) {
      axios
        .delete("http://localhost:5000/api/review/userID", {
          data: { user_id: u },
        })
        .then((response) => {
          console.log(response);
        })
        .catch(err => {
        console.error(err)
      })
    },
    deleteLists(u) {
      axios
        .delete("http://localhost:5000/api/mylist/userID", {
          data: { DELETEuser_id: u },
        })
        .then((response) => {
          console.log(response);
        })
        .catch(err => {
        console.error(err)
      })
    },
  },
};
</script>