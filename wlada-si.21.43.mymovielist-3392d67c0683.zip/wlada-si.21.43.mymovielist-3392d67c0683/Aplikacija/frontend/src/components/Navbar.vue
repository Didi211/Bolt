<template>
  <div id="navbar-wrap">
    <div id="navbar">
      <img @click="scrollToTop" class="logo" src="@/assets/slate.png" />
      <router-link tag="ul" to="/"><h2>MyMovieList.</h2></router-link>
      <template v-if="!authenticated">
        <div class="desktop">
          <ul id="navbar-right">
            <router-link to="/register"
              ><b-icon icon="person-fill"></b-icon>Create Account</router-link
            >
            <router-link to="/login"
              ><b-icon icon="unlock-fill"></b-icon> Log in</router-link
            >
            <router-link to="/browse"
              ><b-icon icon="film"></b-icon> Browse</router-link
            >
          </ul>
        </div>

        <div class="mobile">
          <label for="toggle">&#9776;</label>
          <input type="checkbox" id="toggle" />
          <ul>
            <router-link tag="li" to="/register"
              ><b-icon icon="person-fill"></b-icon> Create Account</router-link
            >
            <router-link tag="li" to="/login"
              ><b-icon icon="unlock-fill"></b-icon> Log in</router-link
            >
            <router-link tag="li" to="/browse"
              ><b-icon icon="film"></b-icon> Browse</router-link
            >
          </ul>
        </div>
      </template>
      <template v-else>
        <div class="desktop">
          <Activity :kor="korisnikId" />
          <ul id="navbar-right">
            <router-link to="/"
              ><b-icon icon="lock-fill"></b-icon>
              <span @click="logout">Log Out</span>
            </router-link>
            <router-link
              :to="{
                name: 'Profile',
                params: { username: user[0].username },
              }"
              ><b-icon icon="person-fill"></b-icon
              >{{ user[0].username }}</router-link
            >
            <router-link to="/browse"
              ><b-icon icon="film"></b-icon> Browse</router-link
            >
            <template v-if="role == admin">
              <router-link to="/admins/admin"><b-icon icon="display"></b-icon> Admin Panel</router-link>
            </template>
          </ul>
        </div>
        <div class="mobile">
          <label for="toggle">&#9776;</label>
          <input type="checkbox" id="toggle" />
          <ul>
            <router-link to="/" tag="li"
              ><b-icon icon="lock-fill"></b-icon>
              <span @click="logout">Log Out</span>
            </router-link>
            <router-link
              :to="{
                name: 'Profile',
                params: { username: user[0].username },
              }"
              tag="li"
              ><b-icon icon="person-fill"></b-icon
              >{{ user[0].username }}</router-link
            >
            <router-link tag="li" to="/browse"
              ><b-icon icon="film"></b-icon> Browse</router-link
            >
            <template v-if="role == admin">
              <router-link to="/admins/admin"><b-icon icon="display"></b-icon> Admin Panel</router-link>
            </template>
          </ul>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import axios from "axios";
import Activity from "@/components/Activity";

export default {
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
      role: "role",
    }),
  },
  name: "Navbar",
  components: {
    Activity,
  },

  data() {
    return {
      korisnik: null,
      korisnikId: null,
      isAdmin: false,
      admin: "admin",
    };
  },
  mounted() {
    // this.ucitajkorisnika();
  },

  methods: {
    ucitajkorisnika() {
      var token = localStorage.getItem("token");
      axios
        .get("http://localhost:5000/api/user/getLoggedUser", {
          headers: {
            Authorization: "Bearer " + token,
          },
        })
        .then((res) => {
          this.korisnik = res.data[0];
          this.korisnikId = res.data[0].id;
          if (this.user[0].role == "admin") {
            this.isAdmin = true;
          } else {
            this.isAdmin = false;
          }
        });
    },

    logout() {
      location.reload();
      localStorage.removeItem("token");
    },
    scrollToTop() {
      window.scrollTo({ top: 0, behavior: "smooth" });
    },
  },
};
</script>



<style scoped>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}
#navbar-wrap {
  position: fixed;
  width: 100%;
  z-index: 999;
  background-color: rgb(14, 4, 34);
  font-family: Tahoma, sans-serif;
}

#navbar {
  display: flex;
  padding: 15px;
  justify-content: space-between;
  background-color: rgb(14, 4, 34);
  font-family: Tahoma, sans-serif;
}

/* NAVIGATION LINKS - browse, sign in, create account */
/* DESKTOP */
#navbar-right a {
  font-family: Tahoma, sans-serif;
  float: right;
  color: #f2f2f2;
  text-align: center;
  margin-top: 3px;
  padding: 10px;
  font-size: 15px;
  height: 20px;
}

#navbar-right a:hover {
  color: #c4c4c4;
  text-decoration: none;
}

/* MOBILE */
.mobile {
  display: none;
}

label {
  margin: 0px 20px 0 0;
  font-size: 30px;
  color: white;
  cursor: pointer;
  position: fixed;
  top: 15px;
  right: 0;
}

#toggle {
  display: none;
}

.mobile ul {
  font-family: Tahoma, sans-serif;
  font-size: 17px;
  text-align: right;
  float: right;
  display: none;
  margin: 45px 5px 0 0;
  background-color: none;
  text-transform: uppercase;
}

.mobile ul li {
  margin: 0;
  width: 100%;
  border-bottom: 1px solid rgba(255, 145, 145, 0.2);
  color: white;
}
.mobile ul li:hover {
  background-color: white;
  color: #325f9a;
  font-weight: bolder;
  cursor: pointer;
}
#toggle:checked ~ ul {
  display: block;
}

/* LOGO, MYMOVIELIST */
h2 {
  margin: 0.2rem 1rem 0 0;
  text-shadow: 0px 0px 3px #000000;
  letter-spacing: 0.8px;
  color: white;
  cursor: pointer;
}

.logo {
  cursor: pointer;
  width: 50px;
  height: fit-content;
}

div {
  display: flex;
  flex-grow: 2;
  justify-content: flex-end;
}

input {
  width: 20%;
  border: none;
  margin-top: 9px;
  height: 30px;
  border-radius: 10px;
  box-sizing: border-box;
  outline: none;
}

/* .author {
  margin: 5px 5px;
  font-weight: bold;
}

.recenzija {
  overflow: hidden;
  color: red;
}

.listreview {
  display: flex;
  justify-content: flex-start !important;
  text-align: left;
}

#details {
  flex-direction: column;
  color: rgb(56, 56, 56);
  font-size: 17px;
}

.routelinks {
  flex-direction: column;
} */

/************ RESPONSIVE ************/

@media only screen and (max-width: 900px) {
  .desktop {
    display: none;
  }

  .mobile {
    display: block;
  }
}
</style>
