<template>
  <div class="btndelete">
    <b-button variant="danger" @click="removeList">Delete List</b-button>
    <!-- <b-modal
      id="modal-1"
      title="Are you sure?"
      @ok="removeList"
      ><h5>Deleting this list will cause the page to refresh.
        </h5>
      </b-modal> -->
  </div>
</template>

<script>
import axios from "axios";
import { mapGetters } from "vuex";
export default {
  name: "DeleteList",
  data() {
    return {
      list: this.listID,
    };
  },
  props: {
    listID: Number,
  },
  methods: {
    removeList() {
      this.deleteList(this.list);
      this.$router.replace({
        name: "Profile",
        params: {
          username: this.user[0].username,
        },
      });
    },
    deleteList(l) {
      console.log(l);
      axios.delete("http://localhost:5000/api/mylist", {
        data: { list_id: l },
      });
    },
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>

<style scoped>
.btndelete {
  margin-left: 5px;
}
</style>