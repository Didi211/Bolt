<template>
  <div>
    <b-button variant="danger" @click="removeMovie">Remove</b-button>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "RemoveFromList",
  data() {
    return {
      movie: this.movieID,
      list: this.listID,
    };
  },
  props: {
    movieID: Number,
    listID: Number,
  },
  methods: {
    removeMovie() {
      this.deleteMovieFromList(this.movie, this.list);
      this.$router.go();
    },
    deleteMovieFromList(m, l) {
      console.log(l);
      axios.delete("http://localhost:5000/api/mylist/removeMovie", {
        data: { movie_id: m, list_id: l },
      });
    },
  },
};
</script>