<template>
    <div class="d-flex justify-content-center mb-6 loader-item">
        <b-spinner  style="width: 5rem; height: 5rem;" label="Large Spinner"></b-spinner>
      </div>
</template>

<script>
export default {
    name: "LoaderItem",
}
</script>

<style>
.loader-item{
    margin:500px;
}
</style>