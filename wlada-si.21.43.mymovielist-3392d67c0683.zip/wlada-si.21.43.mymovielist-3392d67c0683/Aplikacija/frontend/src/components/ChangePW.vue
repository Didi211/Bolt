<template>
  <div>
    <b-button variant="outline-info" v-b-modal.modal-4
      ><b-icon icon="lock"></b-icon>Change Password</b-button
    >
    <b-modal
      size="sm"
      id="modal-4"
      ref="modal"
      title="Change Password"
      @show="resetModal"
      @hidden="resetModal"
      @ok="handleOk"
    >
      <form ref="form" @submit.stop.prevent="handleSubmit">
        <b-form-group
          label="Current password:"
          label-for="password-input"
          invalid-feedback="Must enter current password!"
          :state="passwordState"
        >
          <b-form-input
            id="password-input"
            v-model="password"
            :state="passwordState"
            type="password"
            required
          ></b-form-input>
        </b-form-group>
        <b-form-group
          label="New password:"
          label-for="newpass-input"
          invalid-feedback="Enter new password."
          :state="newpassState"
        >
          <b-form-input
            id="newpass-input"
            v-model="newpass"
            :state="newpassState"
            type="password"
            required
          ></b-form-input>
        </b-form-group>
      </form>
      <p></p>

      <!-- <h5>Page will refresh after changes.</h5> -->
    </b-modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import axios from "axios";
export default {
  name: "ChangePW",
  data() {
    return {
      password: "",
      passwordState: "",
      newpass: "",
      newpassState: "",
    };
  },

  methods: {
    checkFormValidity() {
      const valid = this.$refs.form.checkValidity();
      this.passwordState = valid;
      this.newpassState = valid;
      return valid;
    },
    resetModal() {
      this.password = "";
      this.passwordState = null;
      this.newpass = "";
      this.newpassState = null;
    },
    handleOk(bvModalEvt) {
      bvModalEvt.preventDefault();
      this.handleSubmit();
    },
    handleSubmit() {
      if (!this.checkFormValidity()) {
        return;
      }
      //   console.log("pokusaj");
      this.changePass(this.password, this.newpass);
      this.$nextTick(() => {
        this.$bvModal.hide("modal-4");
        this.$bvModal.hide("modal-prevent-closing");
      });
      // this.$router.go();
    },

    changePass(op, np) {
      axios
        .put("http://localhost:5000/api/user/password", {
          oldPassword: op,
          newPassword: np,
          user_id: this.user[0].id,
        })
        .then((response) => {
          console.log(response);
        });
    },
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>