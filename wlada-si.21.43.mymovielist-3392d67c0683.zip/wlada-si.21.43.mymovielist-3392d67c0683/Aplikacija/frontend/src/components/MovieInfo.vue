<template>
  <div id="tabs">
    <div class="tabs">
      <a
        v-on:click="activetab = 1"
        v-bind:class="[activetab === 1 ? 'active' : '']"
        >CAST</a
      >
      <a
        v-on:click="activetab = 2"
        v-bind:class="[activetab === 2 ? 'active' : '']"
        >CREW</a
      >
      <a
        v-on:click="activetab = 3"
        v-bind:class="[activetab === 3 ? 'active' : '']"
        >GENRES</a
      >
    </div>

    <div class="content">
      <div v-if="activetab === 1" class="tabcontent">
        <a v-for="actor in actors" :key="actor.person_id">
          {{ actor.crew_name }},
        </a>
      </div>
      <div v-if="activetab === 2" class="tabcontent">
        <a v-for="(crewMember, index) in crewMembers" :key="index">
          {{ crewMember.crew_name }} (<i>{{
            crewMember.role.replace("_", " ")
          }}</i
          >),
        </a>
      </div>
      <div v-if="activetab === 3" class="tabcontent">
        <a v-for="(genre, index) in genres" :key="index">
          {{ genre.name }}<br>
        </a>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "MovieInfo",

  data() {
    return {
      activetab: 1,
      id: parseInt(this.$route.params.id),
      actors: [],
      genres: [],
      crewMembers: [],
      crewRoles: [],
    };
  },

  mounted: function () {
    this.getActors();
    this.getCrewMembers();
    this.getGenres();
  },

  methods: {
    getActors() {
      axios.get("http://localhost:5000/api/actor").then((response) => {
        this.actors = response.data.filter(
          (actor) => actor.movie_id === this.id
        );
        // console.log(this.actors);
      });
    },

    getCrewMembers() {
      axios.get("http://localhost:5000/api/crewMember").then((response) => {
        const crewMembActors = response.data.filter(
          (crewMember) => crewMember.movie_id === this.id
        );
        this.crewMembers = crewMembActors.filter((obj) => obj.role != "actor");

        // console.log(this.crewMembers);
      });
    },

    getGenres() {
      axios
        .post("http://localhost:5000/api/genre/movieID", {
          movie_id: this.id,
        })
        .then((response) => {
          this.genres = response.data;
          // console.log(this.genres);
        });
    },
  },
};
</script>

<style scoped>
#tabs {
  margin-top: 30px;
  font-size: 15px;
}

.tabs {
  overflow: hidden;
  margin-left: 0px;
  margin-bottom: -2px;
}

.tabs a {
  float: left;
  cursor: pointer;
  padding: 8px 18px;
  transition: background-color 0.2s;
  border: 1px solid #ccc;
  border-right: none;
  color: rgb(175, 175, 175);
  background-color: rgb(14, 4, 34);
  border-radius: 10px 10px 0 0;
  font-weight: bold;
}
.tabs a:last-child {
  border-right: 1px solid #ccc;
}

.tabs a:hover {
  background-color: #aaa;
  color: #fff;
}

.tabs a.active {
  background-color: #fff;
  color: rgb(43, 15, 99);
  border-bottom: 2px solid #fff;
  cursor: default;
}

.tabcontent {
  padding: 15px;
  background-color: rgb(241, 241, 241);
  border: 1px solid #ccc;
  border-radius: 10px;
  line-height: 23px;
  box-shadow: 3px 3px 6px #e1e1e1;
}
</style>