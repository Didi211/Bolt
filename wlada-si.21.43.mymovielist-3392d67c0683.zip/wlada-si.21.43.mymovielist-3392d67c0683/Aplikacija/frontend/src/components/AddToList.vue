<template>
  <div>
    <b-button variant="info" v-b-modal.modal-prevent-closing
      >Add to list..</b-button
    >
    <b-modal
      id="modal-prevent-closing"
      ref="modal"
      title="Add to list.."
      @show="resetModal"
      @hidden="resetModal"
      @ok="handleSubmit"
    >
      Please select the list to which you want to add this movie:
      <p></p>
      <b-form-select v-model="selected">
        <option v-for="list in lists" :key="list.id" v-bind:value="list.id">
          {{ list.name }}
        </option>
      </b-form-select><br>or..<br>
      <CreateList/>
    </b-modal>
  </div>
</template>

<script>
import axios from "axios";
import CreateList from "@/components/CreateList";
import { mapGetters } from "vuex";
export default {
  name: "AddToList",
  components: {
    CreateList,
  },
  data() {
    return {
      selected: null,
      movie: this.movieID,
      lists: [],
    };
  },
  props: {
    movieID: Number,
  },
  methods: {
    resetModal() {
      this.selected = null;
    },
    handleSubmit() {
      if (this.selected == null) {
        return;
      }
      this.addToList(this.selected);

      this.$nextTick(() => {
        this.$bvModal.hide("modal-prevent-closing");
      });
    },
    addToList(list) {
      axios.post("http://localhost:5000/api/mylist/addMovie", {
        movie_id: this.movie,
        list_id: list,
      });
    },

    loadAllLists() {
      axios
        .get("http://localhost:5000/api/mylist/" + this.user[0].username)
        .then((response) => {
          this.lists = response.data;
        });
    },
  },
  mounted: function () {
    this.loadAllLists();
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>