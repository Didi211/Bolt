<template>
  <div>
    <b-button variant="light" v-b-modal.modal-center>List Settings</b-button>
    <b-modal
      id="modal-center"
      ref="modal"
      title="Edit this list.."
      @show="resetModal"
      @hidden="resetModal"
      @ok="handleOk"
    >
      <p>Page will reload automatically and display the changes.</p>
      <form ref="form" @submit.stop.prevent="handleSubmit">
        <b-form-group
          label="List name:"
          label-for="name-input"
          invalid-feedback="Name is required"
          :state="nameState"
        >
          <b-form-input
            id="name-input"
            v-model="name"
            :state="nameState"
            maxlength="45"
            required
          ></b-form-input>
        </b-form-group>
        <b-form-group
          label="List description:"
          label-for="desc-input"
          invalid-feedback="Description is required"
          :state="descState"
        >
          <b-form-textarea
            id="desc-input"
            v-model="desc"
            rows="3"
            :state="descState"
            required
            maxlength="200"
          ></b-form-textarea>
        </b-form-group>
      </form>
      <div>
        <b-form-checkbox
          id="checkbox-1"
          v-model="status"
          name="checkbox-1"
          value="0"
          unchecked-value="1"
        >
          make this list private
        </b-form-checkbox>
      </div>
    </b-modal>
  </div>
</template>

<script>
import axios from "axios";
import { mapGetters } from "vuex";
export default {
  name: "EditList",
  data() {
    return {
      name: "",
      desc: "",
      descState: null,
      nameState: null,
      status: this.lPrivacy,
      list_id: this.lID,
      list_name: this.lName,
      list_desc: this.lDesc,
    };
  },
  props: {
    lID: Number,
    lName: String,
    lDesc: String,
    lPrivacy: Number,
  },
  methods: {
    checkFormValidity() {
      const valid = this.$refs.form.checkValidity();
      this.nameState = valid;
      this.descState = valid;
      return valid;
    },
    resetModal() {
      this.name = this.list_name;
      this.nameState = null;
      this.desc = this.list_desc;
      this.descState = null;
    },
    handleOk(bvModalEvt) {
      bvModalEvt.preventDefault();
      this.handleSubmit();
    },
    handleSubmit() {
      if (!this.checkFormValidity()) {
        return;
      }
      this.changeList(this.list_id, this.name, this.desc, this.status);
      // this.$emit('listCreated', this.newListID);
      // this.addToList(this.newListID, this.movie);
      this.$nextTick(() => {
        this.$bvModal.hide("modal-center");
      });
      this.$router.go();
    },
    changeList(id, n, d, s) {
      axios
        .put("http://localhost:5000/api/mylist/", {
          list_id: id,
          public: s,
          name: n,
          description: d,
        })
        // .then((response) => {
        //   this.newListID = response.data.insertId;
        // });
    },
    // addToList(listID, m) {
    //   axios.post("http://localhost:5000/api/mylist/addMovie", {
    //     movie_id: m,
    //     list_id: listID,
    //   });
    // },
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>