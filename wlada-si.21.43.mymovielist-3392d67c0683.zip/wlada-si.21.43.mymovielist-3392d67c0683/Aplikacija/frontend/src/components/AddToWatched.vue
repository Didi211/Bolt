<template>
  <div>
    <b-button v-b-modal.modal-1 variant="info"
      >Add to Watched</b-button
    >

    <b-modal id="modal-1" title="Success!" @ok="addToList">
      <h5 class="my-4">Movie added to <i>Watched List</i>.</h5>
    </b-modal>
  </div>
</template>

<script>
import axios from "axios";
// import axios from 'axios';
export default {
  name: "AddToWatched",
  data() {
    return {
      movieID: this.movie,
      userID: this.user,
      listID: 0,
      listExists: false,
    };
  },
  props: {
    movie: Number,
    user: Number,
  },
  
  methods: {
    createList() {
      axios
        .post("http://localhost:5000/api/watchedlist", {
          user_id: this.userID,
        })
        .then((response) => {
          console.log(response.data);
          this.listID = response.data.insertId;
          this.addMovie(this.listID, this.movieID);
        });
    },
    addToList() {
      axios
        .post("http://localhost:5000/api/watchedlist/userID", {
          target_user_id: this.userID,
        })
        .then((response) => {
          console.log(response);
          if (response.data.length == 0) {
            this.createList();
            this.addMovie(this.listID, this.movieID);
          } else {
            this.listID = response.data[0].id;
            axios.post("http://localhost:5000/api/watchedlist/addMovie", {
              list_id: this.listID,
              movie_id: this.movieID,
            })
            .then((response) => {
              console.log(response);
            })
          }
          this.$nextTick(() => {
            this.$bvModal.hide("modal-1");
          });
          this.$router.go();
        });
    },
  },
};
</script>