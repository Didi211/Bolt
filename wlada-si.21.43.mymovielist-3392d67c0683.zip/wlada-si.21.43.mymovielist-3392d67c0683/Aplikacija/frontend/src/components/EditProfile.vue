<template>
  <div class="btn">
    <b-button variant="info" v-b-modal.modal-2
      ><b-icon icon="person-badge"></b-icon> Edit</b-button
    >
    <b-modal
      id="modal-2"
      ref="modal"
      title="Edit your profile"
      @show="resetModal"
      @hidden="resetModal"
      @ok="handleSubmit"
      >
      <p></p>
      <form ref="form" @submit="handleSubmit">
        <b-form-group
          label="Name"
          label-for="name-input"
          invalid-feedback="Name is required"
          :state="nameState"
        >
          <b-form-input
            id="name-input"
            v-model="name"
            :state="nameState"
            required
          ></b-form-input>
        </b-form-group>
        <b-form-group
          label="Surname"
          label-for="surname-input"
          invalid-feedback="Surname is required"
          :state="surnameState"
        >
          <b-form-input
            id="surname-input"
            v-model="surname"
            :state="surnameState"
            required
          ></b-form-input>
        </b-form-group>
        <!-- <b-form-group label="Bio" label-for="bio-input">
          <b-form-textarea
            id="bio-input"
            v-model="bio"
            rows="3"
            max-rows="6"
            placeholder="Introduce yourself.."
          ></b-form-textarea>
        </b-form-group> -->
      </form>
      <p></p><br>*For editing personal information,
      please close this modal and go to <i>Settings.</i>
      <h5>Page will refresh after changes.</h5>
    </b-modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import axios from "axios";
export default {
  name: "EditModal",
  data() {
    return {
      name: "",
      surname: "",
      nameState: null,
      surnameState: null,
      bio: "",
    };
  },
  methods: {
    checkFormValidity() {
      const valid = this.$refs.form.checkValidity();
      this.nameState = valid;
      this.surnameState = valid;
      return valid;
    },
    resetModal() {
      this.name = this.user[0].firstname;
      this.nameState = null;
      this.surname = this.user[0].lastname;
      this.surnameState = null;
      this.bio = this.user[0].bio;
    },
    handleSubmit() {
      if (!this.checkFormValidity()) {
        return;
      }

      console.log("pokusaj");
      this.updateName(this.name, this.surname);

      this.$nextTick(() => {
        this.$bvModal.hide("modal-2");
      });
      this.$router.go();
    },

    updateName(n, s) {
      axios
        .put("http://localhost:5000/api/user/name", {
          firstname: n,
          lastname: s,
          user_id: this.user[0].id,
        })
        .then((response) => {
          console.log(response);
        });
    },
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>

<style scoped>
.btn {
  margin-right: 2px;
}
</style>