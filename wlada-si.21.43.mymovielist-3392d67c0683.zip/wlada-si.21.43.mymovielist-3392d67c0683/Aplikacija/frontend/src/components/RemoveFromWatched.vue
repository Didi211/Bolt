<template>
  <div>
    <b-button v-b-modal.modal-2 variant="danger">
      Remove from Watched
    </b-button>
    <b-modal id="modal-2" title="Done." @ok="deleteMovie">
      <h5 class="my-4">Movie removed from <i>Watched List</i>.</h5>
    </b-modal>
  </div>
</template>

<script>
import axios from "axios";
import { mapGetters } from "vuex";
export default {
  name: "RemoveFromWatched",
  data() {
    return {
      movie: this.movieID,
      list: 0,
    };
  },
  props: {
    movieID: Number,
  },

  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },

  methods: {
    deleteMovie() {
      axios
        .post("http://localhost:5000/api/watchedlist/userID", {
          target_user_id: this.user[0].id,
        })
        .then((response) => {
          this.list = response.data[0].id;
          axios.delete("http://localhost:5000/api/watchedlist/removeMovie", {
            data: { movie_id: this.movie, list_id: this.list },
          });
          this.$nextTick(() => {
            this.$bvModal.hide("modal-2");
          });
          this.$router.go();
        });
    },
  },
};
</script>