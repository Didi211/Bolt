<template>
  <main>
    <div class="watched-info">
      <h4>
            Watched list:
          </h4>
      <div v-if="userlist == user[0].username">
      <b-button variant="info" v-b-modal.modal-1>Edit</b-button>
      <b-modal
        id="modal-1"
        ref="modal"
        title="Edit privacy.."
        @ok="handleSubmit"
      >
        <h5>Manage who can see your <b>Watched List.</b></h5>
        <br />
        <b-form-checkbox
          id="checkbox-1"
          v-model="status"
          name="checkbox-1"
          value="0"
          unchecked-value="1"
        >
          make this list PRIVATE
        </b-form-checkbox>
        <br />
      </b-modal>
      </div>
    </div>
    <vue-horizontal class="horizontal">
      <div class="item" v-for="item in items" :key="item.id">
        <router-link :to="{ name: 'Movie', params: { id: item.id } }">
          <img
            class="image"
            v-bind:src="
              'https://image.tmdb.org/t/p/w185' + item.poster_path
            "
          />
        </router-link>
        <div class="title">
          <h5>{{ item.original_title }}</h5>
          <!-- <RemoveFromWatched :movieID="item.id" :listID="list" /> -->
        </div>
        <!-- <div>
          <p class="description">{{ item.overview }}</p>
        </div> -->
      </div>
    </vue-horizontal>
    <i>*scroll horizontally to navigate</i>
  </main>
</template>
<script>
import VueHorizontal from "vue-horizontal";
import { mapGetters } from "vuex";
import axios from "axios";

export default {
  name: "WatchedList",
  components: {
    VueHorizontal,
  },
  data() {
    return {
      userlist: this.un,
      movies: this.items,
      list: this.listID,
      // privacy: this.is_public,
      status: this.is_public,
    };
  },
  props: {
    items: Array,
    un: String,
    is_public: Number,
    listID: Number,
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
  methods: {
    handleSubmit() {
      this.changeList(this.status, this.user[0].id);
      this.$nextTick(() => {
        this.$bvModal.hide("modal-1");
      });
      this.$router.go();
    },
    changeList(s, u) {
      axios.put("http://localhost:5000/api/watchedlist/", {
        public: s,
        user_id: u,
      })
      .then((response) => {
        console.log(response.data);
        // this.privacy = this.is_public;
      })
    },
  },
};
</script>

<style scoped>
main {
  padding: 0px 30px;
  border-left: 1px solid rgb(156, 156, 156);
  border-right:  1px solid rgb(156, 156, 156);
  margin: 0px 0px -25px 0px;
}
main > div {
  padding: 10px 23px;
}

.watched-info {
  display: flex;
  flex-direction: row;
  margin: 20px 0px 0px 0px;
  padding: 0px;
}

.title {
  max-width: 180px;
}
h4 {
  font-size: 25px;
  color: rgb(43, 43, 43);
  padding-right: 20px;
  margin-left: -15px;
  text-transform: uppercase;
  text-shadow: 0px 1px 1px #30303081;
  font-weight: 600;
  -webkit-text-stroke: 0.1px rgb(255, 255, 255);
}
.image {
  max-width: 180px;
  border-radius: 10px;
}

.item {
  padding: 15px;
  text-align: center;
  color: rgb(143, 143, 143);
  -webkit-text-stroke: 1px rgb(158, 158, 158);
}
</style>
