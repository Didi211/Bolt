<template>
  <div>
    <b-button v-b-toggle.sidebar-1>Activity</b-button>
    <b-sidebar
      id="sidebar-1"
      title="Activity"
      bg-variant="dark"
      text-variant="light"
      width="350px"
      shadow
    >
      <template class="listreview">
        <section
          class="recenzija"
          v-for="recenzija in reviews"
          :key="recenzija.id"
        >
          <template id="details">
            <b-list-group-item class="align-items-center" variant="secondary">
              <section class="routelinks">
                <div v-html="praznoreview"/>
                <router-link
                  :to="{
                    name: 'Profile',
                    params: { username: recenzija.username },
                  }"
                  class="author"
                  ><b-avatar
                    size="40px"
                    variant="info"
                    rounded="circle"
                  ></b-avatar>
                  @{{ recenzija.username }} </router-link
                ><br />
                <router-link
                  :to="{
                    name: 'Movie',
                    params: { id: recenzija.movie_id },
                  }"
                  class="author"
                >
                  rated: {{ recenzija.movie_name }}
                </router-link>
                <star-rating
                  :rating="recenzija.rating"
                  :read-only="true"
                  :show-rating="false"
                  :star-size="20"
                ></star-rating>
                {{ recenzija.description }}
              </section>
            </b-list-group-item>
          </template>
        </section>
      </template>
    </b-sidebar>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import axios from "axios";
import StarRating from "vue-star-rating";
export default {
  name: "Activity",
  components: {
    StarRating,
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
  data() {
    return {
      reviews: [],
      rating: null,
      korisnikid: this.kor,
      praznoreview: null
      //   isAdmin: false,
    };
  },
  props: {
    kor: Number,
  },
  created() {
    this.loadReviews();
  },
  methods: {
    loadReviews() {
      let reviewarraytemp = [];
      axios
        .get("http://localhost:5000/api/activity", {
          user_id: this.korisnikid,
        })
        .then((response) => {
          if(response.data.message != "No recent reviews")
          response.data.forEach((element) => {
            let review2temp = {
              movie_id: null,
              user_id: null,
              rating: null,
              description: "",
              date_time: null,
              id: null,
              username: "",
              movie_name: "",
              //ismyreview: false,
            };

            review2temp.movie_id = element.movie_id;
            review2temp.user_id = element.user_id;
            review2temp.rating = element.rating;
            review2temp.description = element.description;
            review2temp.id = element.id;

            let datum = new Date(element.date_time)
              .toISOString()
              .replace(/T/, " ")
              .replace(/\..+/, "");

            review2temp.date_time = datum;
            axios
              .post("http://localhost:5000/api/user/userID", {
                user_id: element.user_id,
              })
              .then((response2) => {
                review2temp.username = response2.data[0].username;
              })
              .catch((err2) => {
                console.error(err2);
              });

            axios
              .post("http://localhost:5000/api/movie/movieID", {
                movie_id: element.movie_id,
              })
              .then((res) => {
                review2temp.movie_name = res.data[0].original_title;
              })
              .catch((err) => {
                console.error(err);
              });

            reviewarraytemp.push(review2temp);
          });

          this.reviews = reviewarraytemp;
        })
        .catch((err) => {
          this.praznoreview = err.response.data.message
          console.log(this.praznoreview)
        });
    },
  },
};
</script>

<style scoped>
.author {
  margin: 5px 5px;
  font-weight: bold;
}

.recenzija {
  overflow: hidden;
  color: rgb(0, 0, 0);
}

.listreview {
  display: flex;
  justify-content: flex-start !important;
  text-align: left;
}

#details {
  flex-direction: column;
  color: rgb(56, 56, 56);
  font-size: 17px;
  /* font-family: Tahoma, sans-serif; */
}

.routelinks {
  flex-direction: column;
}
</style>