<template>
  <div>
    <b-button variant="info" v-b-modal.modal-center
      ><b-icon icon="folder-plus"></b-icon> New list</b-button
    >
    <b-modal
      id="modal-center"
      ref="modal"
      title="Create a new list.."
      @show="resetModal"
      @hidden="resetModal"
      @ok="handleOk"
    >
      <h5>Page will reload automatically and you'll be able to add movies to your new list.
      </h5><p></p><form ref="form" @submit.stop.prevent="handleSubmit">
        <b-form-group
          label="List name:"
          label-for="name-input"
          invalid-feedback="Name is required"
          :state="nameState"
        >
          <b-form-input
            id="name-input"
            v-model="name"
            :state="nameState"
            maxlength="45"
            required
          ></b-form-input>
        </b-form-group>
        <b-form-group
          label="List description:"
          label-for="desc-input"
          invalid-feedback="Description is required"
          :state="descState"
        >
          <b-form-textarea
            id="desc-input"
            v-model="desc"
            rows="3"
            :state="descState"
            required
            maxlength="200"
          ></b-form-textarea>
        </b-form-group>
      </form>
      <div>
        <b-form-checkbox
          id="checkbox-1"
          v-model="status"
          name="checkbox-1"
          value="0"
          unchecked-value="1"
        >
          make this list private
        </b-form-checkbox>
      </div>
    </b-modal>
  </div>
</template>

<script>
import axios from "axios";
import { mapGetters } from "vuex";
export default {
  name: "CreateList",
  data() {
    return {
      name: "",
      desc: "",
      descState: null,
      nameState: null,
      status: 1,
      newListID: null,
    //   movie: this.movID,
    };
  },
//   props: {
//     movID: Number,
//   },
  methods: {
    checkFormValidity() {
      const valid = this.$refs.form.checkValidity();
      this.nameState = valid;
      this.descState = valid;
      return valid;
    },
    resetModal() {
      this.name = "";
      this.nameState = null;
      this.desc = "";
      this.descState = null;
    },
    handleOk(bvModalEvt) {
      bvModalEvt.preventDefault();
      this.handleSubmit();
    },
    handleSubmit() {
      if (!this.checkFormValidity()) {
        return;
      }
      this.createList(this.name, this.desc, this.status);
        // this.$emit('listCreated', this.newListID);
        // this.addToList(this.newListID, this.movie);
      this.$nextTick(() => {
        this.$bvModal.hide("modal-center");
      });
      this.$router.go();
    },
    createList(n, d, s) {
      axios
        .post("http://localhost:5000/api/mylist/", {
          public: s,
          user_id: this.user[0].id,
          name: n,
          description: d,
        })
        // .then((response) => {
        //   this.newListID = response.data.insertId;
        // });
    },
    // addToList(listID, m) {
    //   axios.post("http://localhost:5000/api/mylist/addMovie", {
    //     movie_id: m,
    //     list_id: listID,
    //   });
    // },
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>