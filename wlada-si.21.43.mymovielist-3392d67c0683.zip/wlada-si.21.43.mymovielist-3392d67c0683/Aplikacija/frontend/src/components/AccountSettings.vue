<template>
  <div class="btn">
    <b-button variant="info" v-b-modal.modal-prevent-closing
      >Settings</b-button
    >
    <b-modal
      id="modal-prevent-closing"
      ref="modal"
      title="Account Settings"
      @show="resetModal"
      @hidden="resetModal"
      @ok="handleOk"
    ><p>Your current email is: <b>{{ user[0].email }}</b></p><br>
      <form ref="form" @submit.stop.prevent="handleSubmit">
        <b-form-group
          label="New email:"
          label-for="email-input"
          invalid-feedback="Email is required"
          :state="emailState"
        >
          <b-form-input
            id="email-input"
            v-model="email"
            :state="emailState"
            type="email"
            placeholder="Type.."
            required
          ></b-form-input>
        </b-form-group>
      </form>
      <p></p>
      <br /><ChangePW/>
      <p></p>*For editing public information close this modal and go to
      <i>Edit.</i>
      <h5>Page will refresh after changes.</h5>
      <div class="delete-acc">
        <DeleteAccount/>
      </div>
    </b-modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import ChangePW from "@/components/ChangePW";
import DeleteAccount from "@/components/DeleteAccount";
import axios from "axios";
export default {
  name: "AccountSettings",
  components: {
    ChangePW,
    DeleteAccount,
  },
  data() {
    return {
      email: "",
      emailState: "",
    };
  },

  methods: {
    checkFormValidity() {
      const valid = this.$refs.form.checkValidity();
      this.emailState = valid;
      return valid;
    },
    resetModal() {
      this.email = "";
      this.emailState = null;
    },
    handleOk(bvModalEvt) {
      bvModalEvt.preventDefault();
      this.handleSubmit();
    },
    handleSubmit() {
      if (!this.checkFormValidity()) {
        return;
      }
      console.log("pokusaj");
      this.updateEmail(this.email);
      console.log(this.email);
      this.$nextTick(() => {
        this.$bvModal.hide("modal-prevent-closing");
      });
      // this.$router.go();
    },

    updateEmail(e) {
      axios
        .put("http://localhost:5000/api/user/email", {
          newEmail: e,
          user_id: this.user[0].id,
        })
        .then((response) => {
          console.log(response);
        });
    },
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>

<style scoped>
.btn {
  margin-right: 2px;
}
</style>