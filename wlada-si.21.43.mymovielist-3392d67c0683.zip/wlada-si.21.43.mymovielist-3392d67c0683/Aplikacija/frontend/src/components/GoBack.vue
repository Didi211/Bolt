<template>
  <span class="controls">
    <div class="mt-3">
      <b-button-group>
        <b-button @click="goBack" variant="info">
          <b-icon icon="arrow-left"></b-icon><br>
        </b-button>
        <b-button @click="home" variant="light">
          <b-icon icon="house"></b-icon><br>
        </b-button>
      </b-button-group>
    </div>
  </span>
</template>

<script>
export default {
  methods: {
    goBack() {
      return this.$router.go(-1);
    },

    home() {
      return this.$router.push("/").catch((err) => {
        this.error = err.response.data.error
      });
    },
  },
};
</script>

<style scoped>
.controls {
  display: flex;
  flex-direction: row;
  position: absolute;
  margin: 30px 10px;
  cursor: pointer;
  z-index: 998;
}
</style>