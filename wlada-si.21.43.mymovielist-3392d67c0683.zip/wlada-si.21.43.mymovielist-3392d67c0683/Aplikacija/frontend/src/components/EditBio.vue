<template>
  <div class="btn">
    <b-button variant="info" v-b-modal.modal-3
      ><b-icon icon="pencil-square"></b-icon
    > Bio</b-button>
    <b-modal
      id="modal-3"
      ref="modal"
      title="Edit your profile"
      @show="resetModal"
      @hidden="resetModal"
      @ok="handleSubmit"
    >
      <b-form-group label="Bio" label-for="bio-input">
        <b-form-textarea
          id="bio-input"
          v-model="bio"
          rows="3"
          max-rows="6"
          placeholder="Introduce yourself.."
        ></b-form-textarea>
      </b-form-group>
      <p></p>
    </b-modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import axios from "axios";
export default {
  name: "EditBio",
  data() {
    return {
      bio: "",
    };
  },

  methods: {
    resetModal() {
      this.bio = this.user[0].bio;
    },
    handleSubmit() {
      console.log("pokusaj");
      this.updateBio(this.bio);
      this.$nextTick(() => {
        this.$bvModal.hide("modal-3");
      });
      this.$router.go();
    },

    updateBio(b) {
      axios
        .put("http://localhost:5000/api/user/bio", {
          bio: b,
          id: this.user[0].id,
        })
        .then((response) => {
          console.log(response);
        });
    },
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>

<style scoped>
.btn {
  margin-right: 2px;
}
</style>