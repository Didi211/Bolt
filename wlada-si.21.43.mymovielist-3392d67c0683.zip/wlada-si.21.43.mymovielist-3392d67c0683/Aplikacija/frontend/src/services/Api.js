import axios from 'axios'
//import store from '@/store/store'

export default () => {
    return axios.create({
        baseUrl: `http://localhost:5000/`,
       // headers: {
         //   Authorization: `Bearer ${store.state.token}`
        //}
    })
}  