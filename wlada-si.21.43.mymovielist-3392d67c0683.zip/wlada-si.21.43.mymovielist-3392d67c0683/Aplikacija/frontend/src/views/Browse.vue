<template>
  <div class="browse">
    <Navbar />
    <template v-if="!ucitano">
      <LoaderItem />
    </template>
    <template v-else>
      <header>
        <h3>
          <b-icon icon="search"></b-icon><br />Start searching<br />movies by
          name:
        </h3>
        <form>
          <fieldset>
            <input
              v-model="searchTerm"
              type="text"
              class="form-control"
              id="searchTerm"
              placeholder="Type here.."
            />
          </fieldset>
        </form>
      </header>
      <div class="searchResults">
        <h2>
          Sort movies:
          <select name="sortBy" id="select" v-model="sortBy">
            <option value="alphabetically">Alphabetically</option>
            <option value="Hrating">Highest rating</option>
            <option value="Lrating">Lowest rating</option>
          </select>
          <select name="showBy" id="select" v-model="showBy">
            <option value="All genres">All genres</option>
            <option v-for="genre in genres" :key="genre.id" :value="genre.name">
              {{ genre.name }}
            </option>
          </select>
        </h2>
        <ul>
          <div v-for="movie in slicedposts" :key="movie.title">
            <li>
              <router-link :to="{ name: 'Movie', params: { id: movie.id } }">
                <div class="poster">
                  <img
                    v-bind:src="
                      'https://image.tmdb.org/t/p/w185' + movie.poster_path
                    "
                  />
                  <div class="overlay_top">
                    <div class="overlay-text">
                      {{ movie.original_title }}
                    </div>
                  </div>
                </div>
              </router-link>
            </li>
          </div>
        </ul>
        <b-pagination-nav
          pills
          v-model="currentPage"
          :link-gen="linkGen"
          :number-of-pages="numPages + 1"
          align="center"
        ></b-pagination-nav>
      </div>
    </template>
    <Footer />
  </div>
</template>

<script scoped>
import axios from "axios";
import LoaderItem from "@/components/LoaderItem";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
export default {
  name: "Browse",
  components: {
    Navbar,
    Footer,
    LoaderItem,
  },

  created() {
    axios.get("http://localhost:5000/api/movie").then((response) => {
      this.movies = response.data;
      // this.ucitano = false;
      axios.get("http://localhost:5000/api/genre").then((response) => {
        this.genres = response.data;
        // this.ucitano = true;
      });
    });
    this.ucitanoSve();
  },

  data: function () {
    return {
      sortBy: "alphabetically",
      showBy: "All genres",
      searchTerm: "",
      maxRating: null,
      movies: [],
      currentPage: 1,
      perPage: 14,
      ucitano: false,
      genres: [],
      genredmovies: [],
    };
  },

  computed: {
    slicedposts() {
      const items = this.filteredMovies;
      return items.slice(
        (this.currentPage - 1) * this.perPage,
        this.currentPage * this.perPage
      );
    },
    numPages() {
      let items;
      if (this.showBy == "All genres") {
        items = this.movies;
      } else {
        this.getMoviesByGenre(this.showBy);
        items = this.genredmovies;
      }
      return Math.ceil(items.length / this.perPage);
    },
    filteredMovies() {
      let tempMovies;
      if (this.showBy == "All genres") {
        tempMovies = this.movies;
      } else {
        this.getMoviesByGenre(this.showBy);
        tempMovies = this.genredmovies;
      }
      //search input
      if (this.searchTerm != "" && this.searchTerm) {
        tempMovies = tempMovies.filter((item) =>
          item.original_title.toUpperCase().match(this.searchTerm.toUpperCase())
        );
      }
      //sort by name
      tempMovies = tempMovies.sort((a, b) => {
        if (this.sortBy == "alphabetically") {
          let fa = a.original_title.toLowerCase(),
            fb = b.original_title.toLowerCase();

          if (fa < fb) {
            return -1;
          }
          if (fa > fb) {
            return 1;
          }
          return 0;
        }
        //sort by rating
        else if (this.sortBy == "Lrating") {
          return a.vote_average - b.vote_average;
        } else if (this.sortBy == "Hrating") {
          return b.vote_average - a.vote_average;
        }
      });
      return tempMovies;
    },
  },

  methods: {
    linkGen(pageNum) {
      return "#page=" + pageNum;
    },
    getMoviesByGenre(g) {
      axios
        .post("http://localhost:5000/api/movie/genre", {
          genre: g,
        })
        .then((response) => {
          this.genredmovies = response.data;
        });
    },
    ucitanoSve() {
      this.ucitano = true;
    },
  },
};
</script>

<style scoped>
.browse {
  display: flex;
  flex-direction: column;
}

/* **************** SEARCH BAR ************** */
header {
  background-image: url(../assets/headerBIG.png);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: bottom;
  position: relative;
  margin-top: 79px;
  height: 60vh;
  text-align: center;
  font-family: Tahoma, sans-serif;
}

h3 {
  font-size: 27px;
  padding-top: 40px;
  position: inherit;
  font-family: Verdana, sans-serif;
  font-weight: 600;
  color: rgb(247, 235, 221);
  text-shadow: 2px 3px 5px #30303081;
  -webkit-text-stroke: 0.6px rgb(151, 151, 151);
}

input {
  margin: 5px 0px 0px 0px;
  padding: 8px 15px;
  background-color: white;
  border: none;
  width: 300px;
  border-radius: 15px;
  border-bottom: 1px solid #ddd;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.4), 0 -1px 1px #fff, 0 1px 0 #fff;
  overflow: hidden;
  font-size: 15px;
}

input:focus {
  outline: none;
  background-color: white;
}

fieldset {
  display: flex;
  justify-content: center;
}

/* ***************** SORT BY *************** */
h2 {
  font-size: 23px;
  text-transform: uppercase;
  text-align: left;
  margin-left: 80px;
  margin-bottom: 30px;
  color: rgb(19, 4, 39);
  font-weight: 600;
  font-family: Tahoma, sans-serif;
}

select {
  margin: 5px 0px 0px 10px;
  padding: 8px 15px;
  background-color: white;
  border: none;
  width: auto;
  border-radius: 15px;
  border-bottom: 1px solid #ddd;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.4), 0 -1px 1px #fff, 0 1px 0 #fff;
  overflow: hidden;
  color: #555555;
  font-size: 15px;
}

select:hover {
  outline: none !important;
  background-color: white;
  color: #555555;
}
select:active {
  outline: none;
  color: #555555;
}

/* ***************** SEARCH RESULTS *************** */
.searchResults {
  padding: 0px 60px;
  width: 100%;
  margin-bottom: 150px;
  background-color: white;
  background-image: linear-gradient(rgb(255, 255, 255), rgb(192, 192, 192));
  display: flex;
  flex-direction: column;
  text-align: center;
}

.searchResults ul {
  width: 98%;
  display: flex;
  justify-content: center;
  list-style: none;
  flex-wrap: wrap;
}

.searchResults ul li img {
  width: 170px;
  margin: 25px;
  border: 1px solid rgb(95, 95, 95);
  border-radius: 10px;
}

/* ****************** HOVER OVERLAY ***************** */

.poster {
  position: relative;
  display: inline-block;
  overflow: hidden;
  max-width: 100%;
  height: auto;
}

.poster .overlay_top {
  opacity: 0;
  position: absolute;
  top: 25px;
  left: 25px;
  right: 25px;
  bottom: 25px;
  background: rgba(58, 58, 58, 0.6);
  border-radius: 10px;
  transition: all 0.4s ease-in-out 0s;
}

.poster:hover .overlay_top,
.poster.active .overlay_top {
  opacity: 1;
}

.poster .overlay-text {
  text-align: center;
  opacity: 1;
  display: inline-block;
  position: absolute;
  font-size: 18px;
  font-family: Tahoma;
  line-height: 20px;
  font-weight: 600;
  -webkit-text-stroke: 0.8px rgb(27, 20, 70);
  top: 50%;
  left: 50%;
  color: white;
  transform: translate(-50%, -50%);
}

/* ************RESPONSIVE************ */
@media only screen and (max-width: 850px) {
  .searchResults ul {
    flex-direction: column;
  }
  h2 {
    display: flex;
    flex-direction: column;
  }

  .searchResults ul {
    display: flex;
    flex-direction: row;
  }

  .searchResults ul li {
    padding: 10px;
  }
  .searchResults ul li img {
    width: 100%;
    margin: 25px 0px 25px 0;
  }

  .poster .overlay_top {
    top: 25px;
    left: 0px;
    right: 0px;
  }

  h2 {
    text-align: center;
    margin: 0 0 0 20px;
  }
}
</style>