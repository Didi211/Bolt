<template>
  <div class="movie-page">
    <Navbar />
    <template v-if="!ucitano">
      <LoaderItem />
    </template>
    <template v-else>
      <div class="header">
        <GoBack />
        <img v-bind:src="movieBackdrop" />
      </div>
      <div class="container">
        <div class="top-section">
          <div class="left-section">
            <img v-bind:src="moviePoster" id="movie-poster" />

            <div class="ratings">
              <span>
                <star-rating
                  v-model="rating"
                  :star-size="30"
                  :rating="this.rating"
                  :show-rating="false"
                  :inline="true"
                ></star-rating>
              </span>
            </div>
            <div class="ratings">
              Vote average: {{ movie.vote_average }}<br />
              Vote count: {{ movie.vote_count }}
            </div>
            <div v-if="authenticated" class="add-movie">
              <AddToList :movieID="id" />
              <p></p>
              <p v-if="!watched">
                <AddToWatched :user="user[0].id" :movie="id" />
              </p>
              <p v-else>
                <RemoveFromWatched :movieID="id" />
              </p>
            </div>
          </div>
          <div class="right-section">
            <div class="movie-title">{{ movie.original_title }}</div>
            <div class="movie-desc">
              <b-icon icon="book"></b-icon> {{ movie.overview }}
              <p></p>
            </div>
            <div class="movie-release">
              <b-icon icon="calendar"></b-icon> Released on:
              {{ movieRelease }}
            </div>
            <div class="movie-runtime">
              <b-icon icon="stopwatch"></b-icon> Runtime:
              {{ movie.runtime }} mins
            </div>
            <MovieInfo />
          </div>
        </div>
        <div class="bottom-section">
          <div v-if="authenticated">
            <template v-if="!this.myreview">
              <b-form-textarea
                type="text"
                v-model="comment"
                placeholder="Share your thoughts.."
                rows="3"
                max-rows="6"
              ></b-form-textarea>
              <p></p>
              <b-button variant="info" @click="handleSubmit"
                >Leave review</b-button
              >
            </template>
            <template v-else>
              <b-form-textarea
                type="text"
                v-model="comment"
                placeholder="Changed your mind? Edit your review here!"
                rows="3"
                max-rows="6"
              ></b-form-textarea>
              <p></p>
              <b-button @click="editSubmit">Edit review</b-button>
            </template>
          </div>
          <div v-else>
            <router-link to="/login">
              <b-button variant="info">
                Sign in to review or rate.
              </b-button></router-link
            >
          </div>
          <h1>REVIEWS</h1>
          <div class="listreview">
            <div
              class="recenzija"
              v-for="recenzija in reviews"
              :key="recenzija.id"
            >
              <div id="details">
                <b-list-group-item class="align-items-center">
                  <b-avatar
                    size="50px"
                    variant="info"
                    rounded="circle"
                  ></b-avatar>
                  <router-link :to="{ name: 'Profile', params: { username: recenzija.username } }" class="author">
                    POSTED: {{ recenzija.date_time }}
                    <p></p>
                    @{{ recenzija.username }}:
                  </router-link>

                  {{ recenzija.description }} <star-rating :rating="recenzija.rating" :read-only="true" :show-rating="false" :star-size="20"></star-rating>
                  <p></p>
                  <b-button @click="deleteReview(recenzija.id)" v-if="recenzija.ismyreview">
                    Delete review
                  </b-button>
                </b-list-group-item>
              </div>
            </div>
          </div>
        </div>
      </div>
    </template>
    <Footer />
  </div>
</template>

<script>
import AddToList from "@/components/AddToList";
import LoaderItem from "@/components/LoaderItem";
import AddToWatched from "@/components/AddToWatched";
import RemoveFromWatched from "@/components/RemoveFromWatched";
import GoBack from "@/components/GoBack";
import { mapGetters } from "vuex";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MovieInfo from "@/components/MovieInfo";
import axios from "axios";
import StarRating from "vue-star-rating";

export default {
  name: "Movie",
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
  components: {
    Navbar,
    Footer,
    StarRating,
    MovieInfo,
    GoBack,
    AddToList,
    AddToWatched,
    RemoveFromWatched,
    LoaderItem,
  },
  data() {
    return {
      id: parseInt(this.$route.params.id),
      ucitano: false,
      moviePoster: "",
      movieBackdrop: "",
      movieRelease: "",
      movie: "",
      reviews: [],
      comment: "",
      rating: null,
      myreview: false, // da li je user vec postovao review BOOLEAN
      myreviewid: null, //ID reviewa za odredjenog korisnika
      watched: false,
    };
  },
  created() {
    this.loadMovies();
    this.loadReviews();
  },
  methods: {
    editSubmit() {
      axios
        .post("http://localhost:5000/api/review/Id", {
          review_id: this.myreviewid,
        })
        .then((response) => {
          console.log(response)
          axios
            .put("http://localhost:5000/api/review", {
              review_id: this.myreviewid,
              user_id: this.user[0].id,
              movie_id: this.movie.id,
              old_rating: response.data[0].rating,
              rating: this.rating,
              description: this.comment,
            })
            .then(() => {
              location.reload();
            })
            .catch((err) => {
              console.error(err);
            });
        });
    },
    deleteReview(id) {

      axios
        .delete("http://localhost:5000/api/review", {
          data: { 
            review_id: id,
            user_id: this.user[0].id,
            movie_id: this.id, 
            rating: this.rating
          },
        })
        .then((response) => {
          //location.reload();
          console.log(response);
        });
    },
    proveri() {
      console.log(this.user[0])
      if (this.user) {
        if(this.user[0].role == "cm" || this.user[0].role == "admin" ){
          this.reviews.map((x) => {
            x.ismyreview = true
            //return
          })
        }
        let first = this.reviews[0];
        var temp = null;
        var indeks = null;
        var found = false;
        this.reviews.forEach((element, index) => {
          if (element.user_id == this.user[0].id) {
            this.myreviewid = element.id;
            element.ismyreview = true; //SLUZI ZA DELETE BUTTON DA SE PRIKAZE PORED REVIEW-A
            this.myreview = true; //SLUZI DA PRIKAZE DRUGACIJI WINDOW ZA ADD REVIEW(PRIKAZACE EDIT REVIEW)
            this.rating = element.rating;
            temp = element;
            indeks = index;
            element = first;
            first = temp;
            found = true;
          }
        });
        if (found) {
          this.reviews.splice(indeks, 1);
          this.reviews.unshift(temp);
        }
      }
    },
    sortiraj() {
      this.reviews.sort(function (a, b) {
        // Turn your strings into dates, and then subtract them
        // to get a value that is either negative, positive, or zero.
        return new Date(b.date_time) - new Date(a.date_time);
      });
      this.proveri();
    },
    handleSubmit() {
      axios
        .post("http://localhost:5000/api/review", {
          movie_id: this.movie.id,
          vote_count: this.movie.vote_count,
          vote_average: this.movie.vote_average,
          rating: this.rating,
          description: this.comment, //OVO JE REVIEW
          user_id: this.user[0].id,
        })
        .then(() => {
          location.reload();
        })
        .catch((err) => {
          console.error(err);
        });
    },
    loadMovies() {
      {
        axios
          .get("http://localhost:5000/api/movie")
          .then((response) => {
            // this.movies = response.data;

            this.movie = response.data.filter((obj) => obj.id === this.id)[0];
            this.moviePoster =
              "https://image.tmdb.org/t/p/w500" +
              response.data.filter((movie) => movie.id === this.id)[0]
                .poster_path;

            this.movieBackdrop =
              "https://image.tmdb.org/t/p/w1280" +
              response.data.filter((movie) => movie.id === this.id)[0]
                .backdrop_path;

            this.movieRelease = response.data
              .filter((movie) => movie.id === this.id)[0]
              .release_date.substr(0, 10);
            this.ucitano = true;
            if (this.authenticated) {
              this.checkWatched();
            }
          })
          .catch((err) => console.error(err));
      }
    },
    loadReviews() {
      let reviewarraytemp = [];
      axios
        .post("http://localhost:5000/api/review/movieId", {
          movie_id: this.id,
        })
        .then((response) => {
          response.data.forEach((element) => {
            let review2temp = {
              movie_id: null,
              user_id: null,
              rating: null,
              description: "",
              date_time: null,
              id: null,
              username: "",
              ismyreview: false,
            };

            review2temp.movie_id = element.movie_id;
            review2temp.user_id = element.user_id;
            review2temp.rating = element.rating;
            review2temp.description = element.description;
            review2temp.id = element.id;

            let datum = new Date(element.date_time)
              .toISOString()
              .replace(/T/, " ")
              .replace(/\..+/, "");

            review2temp.date_time = datum; 
            axios
              .post("http://localhost:5000/api/user/userID", {
                user_id: element.user_id,
              })
              .then((response2) => {
                review2temp.username = response2.data[0].username;
              });
            reviewarraytemp.push(review2temp);
          });

          this.reviews = reviewarraytemp;
          this.sortiraj();
          this.ucitano = true;
        });
    },
    checkWatched() {
      axios
        .post("http://localhost:5000/api/watchedlist/userID", {
          target_user_id: this.user[0].id,
        })
        .then((response) => {
          var list = response.data[0].id;
          // console.log(list);
          axios
            .post("http://localhost:5000/api/watchedlist/movies", {
              list_id: list,
            })
            .then((response) => {
              for (let i = 0; i < response.data.length; i++) {
                if (response.data[i].id === this.id) {
                  // console.log(response2.data[i].id);
                  this.watched = true;
                  this.ucitano = true;
                }
              }
            })
            .catch((err) => console.error(err));
        });
    },
  },
};
</script> 


<style scoped>
.author {
  margin: 10px 5px;
  font-weight: bold;
}

.movie-page {
  background-image: url("../assets/popcorn.png");
  background-repeat: no-repeat;
  background-size: 30%;
  background-position-x: right;
  background-position-y: bottom;
  display: flex;
  flex-direction: column;
  cursor: default;
}

.header {
  display: flex;
  top: 15px;
  position: relative;
  text-align: center;
  padding: 35px;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  z-index: 0;
}

.header img {
  max-width: 115%;
  justify-content: center;
  position: relative;
  left: 50%;
  top: 25px;
  transform: translateX(-50%);
  bottom: 10px;
  max-height: 500px;
  z-index: 0;
}

/* **************** INFO ************** */
.container {
  /* flex-direction: column; */
  background-image: linear-gradient(
    to top left,
    rgb(255, 255, 255),
    rgb(212, 211, 211)
  );
  max-width: 888px;
  background-color: ivory;
  padding: 60px;
  font-family: Trebuchet MS, sans-serif;
  border-bottom-right-radius: 15px;
  border-bottom-left-radius: 15px;
}

.top-section {
  display: flex;
  flex-direction: row;
}
.bottom-section {
  display: flex;
  flex-direction: column;
  float: center;
  text-align: center;
  /* background-color: black; */
  margin-top: 30px;
  padding: 30px;
  background-color: rgb(241, 241, 241);
  border: 1px solid #ccc;
  border-radius: 10px;
  box-shadow: 3px 3px 6px #e1e1e1;
}

.bottom-section h1 {
  font-size: 33px;
  font-family: monospace;
  margin: 10px;
  text-align: left;
  text-decoration: 2px underline dotted;
}
.recenzija {
  /* position: relative; */
  /* display: inline-block; */
  overflow: hidden;
  height: auto;
  flex-direction: column;
  color: red;
}

.listreview {
  flex-direction: row;
  text-align: left;
}

#details {
  flex-direction: column;
  color: rgb(56, 56, 56);
  font-size: 17px;
  /* font-family: Tahoma, sans-serif; */
}

.left-section .right-section {
  width: 50%;
  flex: 1;
  padding: 20px;
}

.left-section .ratings {
  font-family: Tahoma, sans-serif;
  color: whitesmoke;
  text-align: center;
  margin: 5px 0px 10px 0px;
  font-size: 18px;
  line-height: 20px;
  background-color: rgb(1, 1, 29);
  border-radius: 10px;
  box-shadow: 1px 5px 7px -5px #141414;
  padding: 10px;
}

.add-movie {
  margin-top: 40px;
  text-align: center;
}

#movie-poster {
  border: 1px solid rgb(109, 109, 109);
  border-radius: 10px;
  position: relative;
  width: 260px;
}

.right-section .movie-title {
  font-family: Verdana, sans-serif;
  text-align: center;
  font-weight: 600;
  color: white;
  -webkit-text-stroke: 1.4px rgb(8, 8, 43);
  text-shadow: 1px 1px 2px #000000;
  text-transform: none;
  font-size: 35px;
  margin-top: 5px;
  line-height: 33px;
  letter-spacing: 0.1px;
}

.right-section .movie-desc {
  margin-top: 50px;
  flex-grow: 1;
  margin-bottom: 10px;
  border-bottom: 1px solid black;
}

.right-section .movie-release {
  font-family: Trebuchet MS, sans-serif;
  font-size: 15px;
  -webkit-text-stroke: 0.2px rgb(24, 12, 12);
  /* text-shadow: 1px 1px 2px #4d4d4d; */
  line-height: 24px;
  text-align: left;
  margin-top: 30px;
  color: #000000;
}

.right-section .movie-runtime {
  font-family: Trebuchet MS, sans-serif;
  font-size: 15px;
  -webkit-text-stroke: 0.2px rgb(24, 12, 12);
  line-height: 24px;
  text-align: left;
  color: #000000;
}

.right-section {
  margin-left: 50px;
  font-size: 20px;
  font-family: Trebuchet MS, sans-serif;
}

/* ************RESPONSIVE************ */
@media only screen and (max-width: 700px) {
  .container {
    flex-direction: column;
  }

  .top-section {
    flex-direction: column;
  }

  .bottom-section {
    flex-direction: column;
  }

  #movie-poster {
    position: relative;
    width: 100%;
  }

  .right-section {
    margin: 0px;
    padding: 0px;
  }
  .movie-desc {
    text-align: center;
  }
}
</style>