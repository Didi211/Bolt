<template>
  <div id="my-list">
    <Navbar />
    <template v-if="!ucitano">
      <LoaderItem />
    </template>
    <template v-else>
      <div
        class="container"
        v-if="listPrivacy == 1 || user[0].id == listCreatorID"
      >
        <GoBack />
        <div class="header">
          <div class="title">
            <p id="now-showing">Now showing</p>
            <i>{{ listName }}</i> list
          </div>
          <div class="description">
            "<i>{{ listDescription }}</i
            >"
          </div>
          <div class="about">
            <div id="avatar">
              <b-avatar size="50px" variant="light" rounded="circle"></b-avatar>
            </div>
            <div>
              <template v-if="listCreator">
                Created by
                <h4>{{ listCreator.firstname }} {{ listCreator.lastname }},</h4>
                @<router-link
                  :to="{
                    name: 'Profile',
                    params: { username: listCreator.username },
                  }"
                >
                  <a id="username">{{ listCreator.username }}</a>
                </router-link>
              </template>
            </div>
          </div>
          <div class="delete" v-if="listCreator.username == user[0].username">
            <EditList
              :lID="id"
              :lName="listName"
              :lDesc="listDescription"
              :lPrivacy="listPrivacy"
            />
            <DeleteList :listID="id" />
          </div>
        </div>
        <div class="section" v-if="movies">
          <ul>
            <li v-for="movie in movies" :key="movie.id">
              <router-link :to="{ name: 'Movie', params: { id: movie.id } }">
                <img
                  v-bind:src="
                    'https://image.tmdb.org/t/p/w185' + movie.poster_path
                  "
                />
              </router-link>
              <p id="poster-title">{{ movie.original_title }}</p>
              <div v-if="listCreator.username == user[0].username">
                <RemoveFromList :movieID="movie.id" :listID="id" />
                <p></p>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div v-else class="no-permission">
        <h1>You do not have permission to view this page.</h1>
      </div>
      <Footer />
    </template>
  </div>
</template>

<script>
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import LoaderItem from "@/components/LoaderItem";
import GoBack from "@/components/GoBack";
import DeleteList from "@/components/DeleteList";
import RemoveFromList from "@/components/RemoveFromList";
import EditList from "@/components/EditList";
import { mapGetters } from "vuex";
import axios from "axios";
export default {
  name: "List",
  components: {
    Navbar,
    Footer,
    GoBack,
    DeleteList,
    RemoveFromList,
    EditList,
    LoaderItem,
  },

  data() {
    return {
      id: parseInt(this.$route.params.id),
      movies: [],
      listName: "",
      listDescription: "",
      listCreator: "",
      listCreatorID: 0,
      listCreatorUN: "",
      ucitano: false,
    };
  },

  created() {
    this.loadListInfo();
    this.loadMoviesInList();
    // this.loadListOwnerInfo();
  },

  methods: {
    loadMoviesInList() {
      axios
        .post("http://localhost:5000/api/mylist/movies", { list_id: this.id })
        .then((response) => {
          this.movies = response.data;
          this.ucitano = true;
        });
    },

    loadListInfo() {
      axios
        .post("http://localhost:5000/api/mylist/listID", { list_id: this.id })
        .then((response) => {
          this.listName = response.data[0].name;
          this.listDescription = response.data[0].description;
          this.listCreatorID = response.data[0].user_id;
          this.listPrivacy = response.data[0].is_public;
          // console.log(this.listCreatorID);
          this.loadListOwnerInfo();
          // console.log(this.listCreator);
          this.listCreatorUN = this.listCreator.username;
        });
    },

    loadListOwnerInfo() {
      axios
        .post("http://localhost:5000/api/user/userID", {
          user_id: this.listCreatorID,
        })
        .then((response) => {
          this.listCreator = response.data[0];
          //   console.log(response.data);
        });
    },
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
};
</script>

<style scoped>
.no-permission {
  margin: 500px 200px 400px 200px;
}
#my-list {
  background-image: url("../assets/popcorn.png");
  background-repeat: no-repeat;
  background-size: 30%;
  background-position-x: right;
  background-position-y: bottom;
  display: flex;
  flex-direction: column;
  cursor: default;
}

.container {
  display: flex;
  flex-direction: column;
  background-image: linear-gradient(
    to top left,
    rgb(255, 255, 255),
    rgb(212, 211, 211)
  );
  padding: 40px 10px;
  max-width: 888px;
  font-family: Trebuchet MS, sans-serif;
  border-bottom-right-radius: 15px;
  border-bottom-left-radius: 15px;
  margin-bottom: 200px;
}

.header {
  background-image: linear-gradient(
    to top left,
    rgb(37, 106, 211),
    rgba(167, 163, 185, 0.178)
  );
  padding: 90px 0px 10px 0px;
  font-size: 32px;
  text-align: center;
  float: center;
  font-weight: 600;
  color: rgb(223, 223, 223);
  text-shadow: 1px 2px 3px #30303081;
  border: 1px solid rgba(128, 128, 128, 0.548);
  border-radius: 10px;
  -webkit-text-stroke: 1px rgb(6, 2, 90);
}

.header #now-showing {
  margin-bottom: 0px;
  line-height: 20px;
  color: rgb(31, 31, 31);
  text-shadow: 1px 2px 2px #30303081;
  text-transform: uppercase;
  -webkit-text-stroke: 0.1px rgb(212, 209, 255);
}

.title {
  border-bottom: 2px dotted rgba(128, 128, 128, 0.616);
}
.about {
  margin: 30px 0 0 10px;
  color: rgb(20, 20, 20);
  display: flex;
  flex-direction: row;
  text-align: left;
  font-weight: 300;
  -webkit-text-stroke: 0.1px rgb(212, 209, 255);
  text-shadow: none;
  line-height: 20px;
  font-size: 20px;
}

#avatar {
  margin: 10px;
}

.delete {
  display: flex;
  float: right;
  flex-direction: row;
  padding: 5px 15px 5px 10px;
  -webkit-text-stroke: 0px rgb(6, 2, 90);
}

h4 {
  font-weight: 600;
  margin-bottom: 0px;
}

#username {
  color: rgb(23, 11, 65);
  font-weight: 600;
  font-style: oblique;
  -webkit-text-stroke: 0.1px rgba(212, 209, 255, 0.726);
}

.description {
  color: rgb(22, 22, 22);
  font-size: 20px;
  float: center;
  padding: 20px;
  -webkit-text-stroke: 0.1px rgb(212, 209, 255);
  text-shadow: none;
  border-bottom: 2px dotted rgba(128, 128, 128, 0.616);
}

.section {
  display: flex;
  padding: 15px;
}

.section ul {
  width: 98%;
  text-align: center;
  display: flex;
  justify-content: center;
  list-style: none;
  flex-wrap: wrap;
}

.section ul li img {
  width: 200px;
  height: 300px;
  margin: 25px 25px 5px 25px;
  border: 1px solid rgb(95, 95, 95);
  border-radius: 10px;
}

#poster-title {
  margin-left: 30px;
  font-size: 18px;
  max-width: 190px;
  font-family: Tahoma;
  line-height: 20px;
  font-weight: 600;
  -webkit-text-stroke: 0.8px rgb(151, 151, 151);
}

.section ul li:hover {
  border-radius: 10px;
  color: rgb(95, 134, 167);
  box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.507);
}
</style>