<template>
  <div class="home">
    <Navbar />
    <template v-if="!ucitano">
      <LoaderItem />
    </template>
    <template v-else>
      <div id="main-section">
        <header>
          <div class="intro">
            <template v-if="!authenticated">
              <h1>
                Stay updated with the latest
                <br />releases, share your thoughts, <br />explore.
                <br />
                <router-link to="/register">
                  <button class="btn">JOIN US NOW</button></router-link
                >
                <p>
                  Join us today and find movies specifically designed for you,
                  make your lists, share with friends, and
                  <b>more</b>. Register as soon as today!
                </p>
              </h1>
            </template>
            <template v-else>
              <h1>
                Welcome back, <i id="user-name">{{ user[0].firstname }}</i> !
                <br />We're glad to see <br />you're back.
                <br />
                <router-link
                  :to="{
                    name: 'Profile',
                    params: { username: user[0].username },
                  }"
                >
                  <button class="btn">View Profile</button></router-link
                >
                <p>
                  Be sure to scroll down and see the new movies we added, or
                  simply click on browse and start searching by yourself. And
                  while you're at it, tell a <b>friend</b> to come join us too!
                </p>
              </h1>
            </template>
          </div>
        </header>
      </div>
      <div class="newlyAdded">
        <div class="sectionTitle">
          <h2>NEWLY ADDED</h2>
          <router-link to="/browse" class="btnRed">View more</router-link>
        </div>
        <ul>
          <li v-for="movie in movies.slice(86, 100)" :key="movie.id">
            <router-link :to="{ name: 'Movie', params: { id: movie.id } }">
              <img
                v-bind:src="
                  'https://image.tmdb.org/t/p/w185' + movie.poster_path
                "
              />
            </router-link>
            <p id="poster-title">{{ movie.original_title }}</p>
          </li>
        </ul>
      </div>
      <div class="searchMore">
        <h2>Didn't find what <br />you're looking for?</h2>

        <router-link to="/browse"
          ><button class="btnRed">BROWSE</button></router-link
        >
      </div>
    </template>
    <Footer />
  </div>
</template>




<script>
import { mapGetters } from "vuex";
import Navbar from "@/components/Navbar";
import axios from "axios";
import Footer from "@/components/Footer";
import LoaderItem from "@/components/LoaderItem";
export default {
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
    }),
  },
  name: "WelcomePage",
  data() {
    return {
      movies: [],
      ucitano: false,
    };
  },

  components: {
    Navbar,
    Footer,
    LoaderItem,
  },

  beforeMount() {},

  created() {
    axios.get("http://localhost:5000/api/movie").then((response) => {
      this.movies = response.data;
      this.ucitano = true;
    });
  },

  methods: {},
};
</script>




<style scoped>
.home {
  display: flex;
  flex-direction: column;
  cursor: default;
}

.home #main-section {
  display: flex;
  margin-top: 79px;
  font-family: Tahoma, sans-serif;
}

/* FOR WHEN LOGGED IN */
#user-name {
  color: rgb(36, 19, 83);
  font-family: Verdana;
}

/******************** MAIN TEXT & HEADER ******************/

header {
  background-image: url(../assets/headerBIG.png);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  height: 90vh;
  min-height: 700px;
  width: 100%;
  padding: 0 5%;
  position: relative;
}

h1 {
  font-size: 30px;
  font-weight: 600;
  color: white;
  text-align: center;
  position: absolute;
  margin-left: 10px;
  text-shadow: 2px 3px 5px #30303081;
  -webkit-text-stroke: 0.6px rgb(151, 151, 151);
}

.btn {
  margin-top: 40px;
  width: 200px;
  font-size: 20px;
  line-height: 45px;
  font-weight: 700;
  background-color: white;
  border-radius: 30px;
  color: #0f0a24;
}

.btn:hover {
  text-decoration: underline;
}

.intro {
  width: 40%;
  float: left;
  text-align: center;
  margin: 150px 0px 0px 50px;
}

header p {
  color: white;
  font-size: 16px;
  opacity: 0.8;
  margin-top: 40px;
  width: 460px;
  -webkit-text-stroke: 0px;
  text-align: left;
}

/* View More & Search buttons*/
.btnRed {
  text-decoration: none;
  color: #0f0a24;
  font-size: 15px;
  font-weight: 650;
  letter-spacing: 1px;
  border-radius: 10px;
}

.sectionTitle .btnRed:hover {
  text-decoration: underline;
}

.sectionTitle .btnRed {
  margin-left: 10px;
}

/***************************** NEWLY ADDED *****************/
.newlyAdded {
  width: 100%;
  padding: 30px;
  margin-bottom: 150px;
  background-color: white;
  background-image: linear-gradient(rgb(255, 255, 255), rgb(192, 192, 192));
  display: flex;
  flex-direction: column;
}

.sectionTitle h2,
.sectionTitle router-link {
  display: inline-block;
  vertical-align: middle;
}

.sectionTitle h2 {
  color: rgb(95, 95, 95);
}

.sectionTitle router-link {
  margin-left: 20px;
}

.sectionTitle {
  margin: -20px 0 20px 20px;
}

.newlyAdded ul {
  width: 98%;
  text-align: center;
  display: flex;
  justify-content: center;
  list-style: none;
  flex-wrap: wrap;
}

.newlyAdded ul li img {
  width: 200px;
  height: 300px;
  margin: 25px 25px 5px 25px;
  border: 1px solid rgb(95, 95, 95);
  border-radius: 10px;
}

#poster-title {
  margin-left: 30px;
  font-size: 18px;
  max-width: 190px;
  font-family: Tahoma;
  line-height: 20px;
  font-weight: 600;
  -webkit-text-stroke: 0.8px rgb(151, 151, 151);
}

.newlyAdded ul li:hover {
  border-radius: 10px;
  color: rgb(95, 134, 167);
  box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.507);
}

/************* END NOTE, SEARCH BAR *****************/

.searchMore {
  text-align: center;
  font-family: Tahoma, sans-serif;
  margin-bottom: 80px;
}

.searchMore .btnRed {
  border-radius: 20px;
  border: 1px solid #a7a7a7;
  background-color: #0f0a24;
  color: whitesmoke;
  font-size: 0.8rem;
  font-weight: bold;
  letter-spacing: 1px;
  text-transform: uppercase;
  width: 90px;
}
.searchMore .btnRed:hover {
  text-decoration: none;
  background-color: rgb(136, 118, 106);
  transition: background-color 0.3s linear;
}

h2 {
  font-size: 30px;
  font-weight: 600;
  color: #dfdede;
  -webkit-text-stroke-width: 0.1px;
  -webkit-text-stroke-color: rgb(133, 133, 133);
}

/********************** RESPONSIVE *****************/

@media only screen and (max-width: 700px) {
  header {
    height: 70vh;
    min-height: 500px;
  }
  .intro {
    margin-top: 100px;
  }
  .newlyAdded ul li img {
  margin: 25px 20px 5px 25px;
  }
}

/* @media only screen and (max-width: 700px) {
  header {
    background-position: center;
    height: 70vh;
    min-height: 400px;
  }

  h1 {
    text-align: left;
    position: relative;
    width: 110%;
    margin: 0;
    top: 80px;
    font-size: 30px;
  }

  .intro {
    width: 90%;
    float: center;
    margin: 30px 0px 0px 30px;
    text-align: center;
  }

  header p {
    display: none;
  }

  .newlyAdded ul {
    width: 95%;
    flex-direction: column;
  }

  .newlyAdded ul li img {
    width: 95%;
    height: auto;
    margin: 25px 0 5px 0px;
  }

  #poster-title {
    font-size: 28px;
    margin-left: 0px;
    max-width: 100%;
    line-height: 25px;
  }
} */
</style>