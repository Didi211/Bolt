<template>
  <article>
    <div class="container">
      <router-link to="/"><button id="closeBtn"><b-icon icon="x"></b-icon></button></router-link>
      <div class="leftBox">
        <form class="sign-in" @submit.prevent>
          <h2>Welcome back!</h2>
          <p>Enter your information to log back in.</p>
          <br>
          <div class = "error" v-html="error"/>
          <br>
          <b-icon icon="person-fill"></b-icon> <input required type="text" v-model = "username" placeholder="Username" />
          <br>
          <b-icon icon="lock"></b-icon> <input required type="password" v-model = "password" placeholder="Password" />
          <p>
            
            <!--<button class="controls" onclick = "login" input type="submit">Log in</button> -->
            <button class="controls" type="submit" @click="login2">Log in</button>
          
            <br />
            <router-link to="/register"
              ><button class="controls" id="mobileBtn">
                Register
              </button></router-link
            >
          </p>
        
        </form>
      </div>
      <div class="overlay-container">
        <div class="overlay">
          <div class="rightBox">
            <h2>Don't have an account?</h2>
            <p>
              Create an account and join us now by clicking on the button below!
            </p>
            <router-link to="/register"
              ><button class="controls">Register</button></router-link
            >
            <router-link to="/"
              ><button class="controls" id="no-thanks">No thanks</button></router-link
            >
          </div>
        </div>
      </div>
    </div>
    <Footer/>
  </article>
</template>

<script>
import { mapGetters } from 'vuex'
import { mapActions } from 'vuex'
import axios from 'axios'
import Footer from '../components/Footer.vue';

export default {
  computed: {
    ...mapGetters({
        authenticated: 'authenticated',
        user: 'user',
    })
  },
  components: { Footer },
  name: "Login",
  data() {
    return {
       
        username: "",
        password: "",
        error: null
      }
     },
  mounted(){
  //   this.checkisLoggedIn();
  },
  methods: {
    ...mapActions({
      signIn: 'signIn'
    }),

    checkisLoggedIn(){
      var token = localStorage.getItem("token");
      axios
        .get("http://localhost:5000/api/user/getLoggedUser", {
          headers: {
            Authorization: "Bearer " + token,
          },
        }).then(() => {
          this.$router.replace({ name: 'WelcomePage' }); 
        }).catch(() => {
          
        })
    },
    async login2(){

      let userloc = {
        username: this.username,
        password: this.password
      }
      
      this.signIn(userloc).then(() => {
         this.$router.push({
           name: 'WelcomePage'
         })
      }).catch((err) => {
        this.error = err.response.data.error
      })

      /*let userloc = {
        username: this.username,
        password: this.password
      }
      AuthenticationService.login({
        username: this.username,
        password: this.password
      }).then(res => {
        console.log(res.data)
      })
      .catch(err => console.error(err))
*/

    },
    async login() {
      
      axios.post('http://localhost:5000/login',{
        username: this.username,
        password: this.password
      })
      .then( ()=> {
        
       // this.$store.dispatch('setToken', res.data.token)
        //localStorage.setItem("token", res.data.token);
        //this.$store.dispatch('setUser', res.data.user)
        this.$router.replace({ name: 'WelcomePage' }); 

        })
      .catch(err => console.error(err));

     /* try{           //NACIN SA YT KLIPA, NZM STO NECE

        const response = await AuthenticationService.login({
          username: this.username,
          password: this.password
        })
  
        console.log(response.data)
      }
      catch(error){
        this.error = error.response.data.error
      }
      */
      
     /* axios.post("/login", this.data).then((response) => {  //IDJOS SA LOKAL STORIDZ ZA TOKEN
        console.log(response.data);

        //Store token to local storage
        localStorage.setItem("token", response.data.token);

        //Store in variable role or store it to local storage
        window.role = "Admin";
        //localStorage.setItem("role", response.data.role.toLowerCase());
      });*/
    },

  },
};
</script>

<style scoped>

.error {
  color: red
}
#mobileBtn {
  display: none;
}
.container {
  position: relative;
  margin-top: 100px;
  margin-bottom: 400px;
  width: 768px;
  height: 480px;
  border-radius: 10px;
  font-family: Tahoma, sans-serif;
  line-height: 20px;
  overflow: hidden;
  box-shadow: 0 5px 5px #474747, 1px 5px 5px #474747;
  background: linear-gradient(to bottom, #ffffff, #ccc);
}

.overlay-container {
  position: absolute;
  top: 0px;
  left: 50%;
  width: 50%;
  height: 100%;
  overflow: hidden;
  z-index: 100;
}

.overlay {
  position: relative;
  left: -100%;
  height: 90%;
  width: 200%;
  color: rgb(65, 62, 71);
}

.leftBox {
  position: absolute;
  top: 30px;
  display: flex;
  align-items: center;
  justify-content: space-around;
  flex-direction: column;
  padding: 80px 40px;
  width: 50%;
  height: 100%;
  text-align: center;
  color: rgb(65, 62, 71);
}

.rightBox {
  position: absolute;
  top: 30px;
  display: flex;
  align-items: center;
  justify-content: space-around;
  flex-direction: column;
  padding: 80px 40px;
  width: 50%;
  height: 100%;
  text-align: center;
  right: 0;
}

h2 {
  margin: 0;
}

p {
  margin: 22px 40px;
}

button {
  border-radius: 20px;
  border: 1px solid #a7a7a7;
  background-color: rgb(96, 92, 102);
  color: whitesmoke;
  font-size: 0.8rem;
  font-weight: bold;
  letter-spacing: 1px;
  text-transform: uppercase;
}

.controls {
  padding: 10px 30px;
  width: 150px;
  margin-top: 20px;
}
#no-thanks, #closeBtn {
  background-color: rgb(67, 55, 95);
}

#closeBtn {
  margin: 10px 0px;
  padding: 3px;
  width: 50px;
  height: 40px;
  font-size: 30px;
  color: whitesmoke;
}

#closeBtn:hover, #no-thanks:hover {
  background-color: rgb(19, 10, 34);
  transition: background-color 0.3s linear;
}

button:hover {
  text-decoration: none;
  background-color: rgb(19, 10, 34);
  transition: background-color 0.3s linear;
}
input {
  margin-top: 10px;
  margin-right:20px;
  padding: 8px 15px;
  background-color: white;
  border: none;
  width: calc(100% - 60px);
  border-radius: 15px;
  border-bottom: 1px solid #ddd;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.4), 0 -1px 1px #fff, 0 1px 0 #fff;
  overflow: hidden;
  font-size: 12px;
}

input:focus {
  outline: none;
  background-color: white;
}

@media only screen and (max-width: 700px) {
  .container {
    margin-top: 10px;
    width: 90%;
    height: relative;
  }

  .leftBox {
    width: 100%;
    left: 0;
  }

  .rightBox {
    display: none;
  }

  #mobileBtn {
    display: inline-block;
  }
}
</style>