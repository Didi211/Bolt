<template>
  <div id="user-profile">
    <Navbar />
    <template v-if="!ucitano">
      <LoaderItem />
    </template>
    <template v-else>
      <div class="container" v-if="role == admin">
        <GoBack />

        <div class="title">
          <p id="now-showing">Admin settings</p>
        </div>

        <br />
        <h3 v-if="activetab === 1">
          <b-icon icon="search"></b-icon>Search users by username:
        </h3>
        <h3 v-if="activetab === 2">
          <b-icon icon="search"></b-icon>Search movies by name:
        </h3>

        <form>
          <fieldset>
            <input
              v-model="searchTerm"
              type="text"
              class="form-control"
              id="searchTerm"
              placeholder="Type here.."
            />
          </fieldset>
        </form>

        <div class="tabs">
          <a
            v-on:click="activeTabUsers"
            v-bind:class="[activetab === 1 ? 'active' : '']"
            >Profiles</a
          >
          <a
            v-on:click="activeTabMovies"
            v-bind:class="[activetab === 2 ? 'active' : '']"
            >Movie</a
          >
        </div>

        <div v-if="activetab === 1">
          <table id="allUsers" class="table mt-2">
            <tbody>
              <tr>
                <th scope="col">#</th>
                <th scope="col">username</th>
                <th scope="col">email</th>
                <th scope="col">firstname</th>
                <th scope="col">lastname</th>
                <th scope="col">role</th>
                <th scope="col">alter role</th>
                <th scope="col">delete</th>
              </tr>

              <tr v-for="profilce in slicedusers" :key="profilce.id">
                <td>{{ profilce.id }}</td>
                <td>{{ profilce.username }}</td>
                <td>{{ profilce.email }}</td>
                <td>{{ profilce.firstname }}</td>
                <td>{{ profilce.lastname }}</td>
                <td>{{ profilce.role }}</td>

                <template v-if="!checkIfAdmin(profilce.role)">
                  <template v-if="checkRole(profilce.role)">
                    <td>
                      <button @click="changeToMember(profilce.id)">
                        Demote to mem
                      </button>
                    </td>
                  </template>
                  <template v-else>
                    <td>
                      <button @click="changeToCM(profilce.id)">
                        Promote to CM
                      </button>
                    </td>
                  </template>
                  <td>
                    <button
                      class="buttondel"
                      @click="deleteProfile(profilce.id)"
                    >
                      Delete
                    </button>
                  </td>
                </template>
              </tr>
            </tbody>
          </table>
        </div>

        <div v-if="activetab === 2">
          <table id="allUsers" class="table mt-2">
            <tbody>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">release date</th>
                <th scope="col">runtime</th>
                <th scope="col">vote average</th>
                <th scope="col">watched</th>
                <th scope="col">delete</th>
              </tr>

              <tr v-for="filmcici in slicedmovies" :key="filmcici.id">
                <td>{{ filmcici.id }}</td>
                <td>{{ filmcici.name }}</td>
                <td>{{ filmcici.release_date }}</td>
                <td>{{ filmcici.runtime }}</td>
                <td>{{ filmcici.vote_average }}</td>
                <td>{{ filmcici.watched }}</td>
                <td>
                  <button class="buttondel" @click = "deleteMovie(filmcici.id)">
                    Delete
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <b-pagination-nav
          v-if="activetab === 1"
          pills
          v-model="currentPage"
          :link-gen="linkGen"
          :number-of-pages="numPagesUsers"
          align="center"
        ></b-pagination-nav>

        <b-pagination-nav
          v-if="activetab === 2"
          pills
          v-model="currentPageMovies"
          :link-gen="linkGen"
          :number-of-pages="numPagesMovies"
          align="center"
        ></b-pagination-nav>
      </div>
      <div v-else class="no-permission">
        <h1>You do not have permission to view this page.</h1>
      </div>
    </template>
    <Footer />
  </div>
</template>


<script>
import { mapGetters } from "vuex";
import Navbar from "@/components/Navbar";
import axios from "axios";
import LoaderItem from "@/components/LoaderItem";
import Footer from "@/components/Footer";
import GoBack from "@/components/GoBack";

export default {
  components: {
    Navbar,
    Footer,
    GoBack,
    LoaderItem,
  },
  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user", //VRACA ARRAY, TKD MORAS ARRAY[0] CAK IAKO JE 1 ELEMENT
      role: "role",
    }),

    slicedusers() {
      const items = this.filteredUsers;
      return items.slice(
        (this.currentPage - 1) * this.perPage,
        this.currentPage * this.perPage
      );
    },
    numPagesUsers() {
      return Math.ceil(this.users.length / this.perPage);
    },

    filteredUsers() {
      let tempUsers = this.users;

      if (this.searchTerm != "" && this.searchTerm) {
        tempUsers = tempUsers.filter((item) =>
          item.username.toUpperCase().match(this.searchTerm.toUpperCase())
        );
      }

      return tempUsers;
    },

    slicedmovies() {
      const items = this.filteredMovies;
      return items.slice(
        (this.currentPageMovies - 1) * this.perPage,
        this.currentPageMovies * this.perPage
      );
    },

    numPagesMovies() {
      return Math.ceil(this.movies.length / this.perPage);
    },

    filteredMovies() {
      let tempMovies = this.movies;

      if (this.searchTerm != "" && this.searchTerm) {
        tempMovies = tempMovies.filter((item) =>
          item.name.toUpperCase().match(this.searchTerm.toUpperCase())
        );
      }

      return tempMovies;
    },
  },
  name: "Admin",

  data() {
    return {
      activetab: 1,
      currentPage: 1,
      perPage: 10,
      searchTerm: "",
      ucitano: false,
      users: [],

      movies: [],
      // searchTermMovies: "",
      currentPageMovies: 1,
      admin: "admin",
    };
  },

  created() {
    this.loadProfiles();
    this.loadMovies();
  },

  methods: {
    activeTabUsers() {
      this.activetab = 1;
      this.currentPage = 1;
      this.searchTerm = "";
    },
    activeTabMovies() {
      this.activetab = 2;
      this.currentPageMovies = 1;
      this.searchTerm = "";
    },

    checkIfAdmin(role) {
      if (role == "admin") {
        return true;
      } else {
        return false;
      }
    },

    deleteProfile(idclicked) {
      axios
        .delete("http://localhost:5000/api/user", {
          data: { id: idclicked },
        })
        .then(() => {
          location.reload();
        })
        .catch((err) => {
          console.error(err);
        });
    },

    changeToCM(idclicked) {
      axios
        .put("http://localhost:5000/api/user/promote", {
          user_id: idclicked,
        })
        .then(() => {
          location.reload();
        })
        .catch((err) => {
          console.error(err);
        });
    },

    changeToMember(idclicked) {
      axios
        .put("http://localhost:5000/api/user/demote", {
          user_id: idclicked,
        })
        .then(() => {
          location.reload();
        })
        .catch((err) => {
          console.error(err);
        });
    },

    linkGen(pageNum) {
      return "#page=" + pageNum;
    },

    checkRole(uloga) {
      if (uloga == "cm") {
        return true;
      } else {
        return false;
      }
    },
    loadProfiles() {
      axios.get("http://localhost:5000/api/user").then((response) => {
        response.data.forEach((element) => {
          var userloc = {
            id: null,
            username: "",
            email: "",
            firstname: "",
            lastname: "",
            role: "",
          };

          userloc.id = element.id;
          userloc.username = element.username;
          userloc.email = element.email;
          userloc.firstname = element.firstname;
          userloc.lastname = element.lastname;
          userloc.role = element.role;

          this.users.push(userloc);
          this.ucitano = true;
        }); //id username email firstname lastname role
      });
    },

    loadMovies() {
      axios
        .get("http://localhost:5000/api/movie")
        .then((response) => {
          //var slicendice = response.data.slice(0, 10) //VRATI GA POSLE NA SVE VFILMOVE
          //console.log(slicendice)
          response.data.forEach((element) => {
            var movieloc = {
              id: null,
              name: "",
              release_date: "",
              runtime: "",
              vote_average: null,
              watched: null,
            };

            movieloc.id = element.id;
            movieloc.name = element.original_title;
            movieloc.release_date = element.release_date.substring(0, 10);
            movieloc.runtime = `${element.runtime} min`;
            movieloc.vote_average = element.vote_average;
            movieloc.watched = element.watched;

            this.movies.push(movieloc);
          });
        })
        .then(() => {
          console.log(this.movies);
        });
    },

    deleteMovie(idClicked) {
      console.log(idClicked);

      axios
        .delete("http://localhost:5000/api/movie", {
          data: { movie_id: idClicked },
        })
        .then(() => {
          location.reload();
        })
        .catch((err) => {
          console.error(err);
        });
    },
  },
};
</script>

<style scoped>
h3 {
  margin: 10px 0px;
}

#user-profile {
  background-image: url("../assets/popcorn.png");
  background-repeat: no-repeat;
  background-size: 30%;
  background-position-x: right;
  background-position-y: bottom;
  display: flex;
  flex-direction: column;
  cursor: default;
}

.container {
  margin-top: 45px;
  display: flex;
  flex-direction: column;
  background-image: linear-gradient(
    to top left,
    rgb(255, 255, 255),
    rgb(212, 211, 211)
  );
  max-width: 950px;
  background-color: ivory;
  padding: 40px 10px;
  font-family: Trebuchet MS, sans-serif;
  border-bottom-right-radius: 15px;
  border-bottom-left-radius: 15px;
  margin-bottom: 300px;
}

.section {
  display: flex;
  padding: 35px;
  margin: 0px 60px;
  border-right: 1px solid rgb(148, 148, 148);
  border-left: 1px solid rgb(148, 148, 148);
}

.title {
  background-image: linear-gradient(
    to top left,
    rgb(37, 106, 211),
    rgba(167, 163, 185, 0.178)
  );
  padding: 90px 0 30px 0;
  font-size: 32px;
  text-align: center;
  float: center;
  font-weight: 600;
  color: rgb(223, 223, 223);
  text-shadow: 1px 2px 3px #30303081;
  border: 1px solid rgba(128, 128, 128, 0.548);
  border-radius: 10px;
  -webkit-text-stroke: 1px rgb(6, 2, 90);
}

.title #now-showing {
  margin-bottom: 0px;
  line-height: 20px;
  color: rgb(31, 31, 31);
  text-shadow: 1px 2px 2px #30303081;
  text-transform: uppercase;
  -webkit-text-stroke: 0.1px rgb(212, 209, 255);
}

table,
th,
td {
  border: 1px solid black;
  border-collapse: collapse;
}
button {
  display: inline-block;
  background: #000;
  color: #fff;
  border: none;
  padding: 10px 20px;
  margin: 5px;
  border-radius: 5px;
  cursor: pointer;
  text-decoration: none;
  font-size: 15px;
  font-family: inherit;
}
button:focus {
  outline: none;
}
button:active {
  transform: scale(0.98);
}
button-block {
  display: block;
  width: 100%;
}

#allUsers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#allUsers td,
#allUsers th {
  border: 1px solid #ddd;
  padding: 8px;
}
.no-permission {
  margin: 500px 200px 400px 200px;
}

#allUsers tr:nth-child(even) {
  background-color: #f2f2f2;
}

#allUsers tr:hover {
  background-color: #ddd;
}

#allUsers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #0b96c0;
  color: white;
}

.buttondel {
  background-color: #f44336;
}

.tabs {
  overflow: hidden;
  margin-top: 10px;
  margin-bottom: -10px;
}

.tabs a {
  float: left;
  cursor: pointer;
  padding: 8px 18px;
  transition: background-color 0.2s;
  border: 1px solid #ccc;
  border-right: none;
  color: rgb(175, 175, 175);
  background-color: rgb(14, 4, 34);
  border-radius: 10px 10px 0 0;
  font-weight: bold;
}
.tabs a:last-child {
  border-right: 1px solid #ccc;
}

.tabs a:hover {
  background-color: #aaa;
  color: #fff;
}

.tabs a.active {
  background-color: #fff;
  color: rgb(43, 15, 99);
  border-bottom: 2px solid #fff;
  cursor: default;
}

.tabcontent {
  padding: 15px;
  background-color: rgb(241, 241, 241);
  border: 1px solid #ccc;
  border-radius: 10px;
  line-height: 23px;
  box-shadow: 3px 3px 6px #e1e1e1;
}
</style>