<template>
  <article>
    <div class="container">
      <div class="box">
        <form class="sign-up" @submit.prevent>
          <h2>Let's get started.</h2>
          Fill out the form with the required information.
          <br /><b-icon icon="pen"></b-icon>
          <input type="text" v-model="firstname" placeholder="First Name" />
          <br /><b-icon icon="pencil"></b-icon>
          <input type="text" v-model="lastname" placeholder="Last Name" />

          <br /><b-icon icon="envelope"></b-icon>
          <input required type="email" v-model="email" placeholder="Email" />
          <br /><b-icon icon="person-fill"></b-icon>
          <input
            required
            type="text"
            v-model="username"
            placeholder="Username"
          />
          <br /><b-icon icon="lock"></b-icon>
          <input
            required
            type="password"
            v-model="password"
            placeholder="Password"
          />

          <!-- <button class="controls" @click="dekili">Create Account</button> -->
          <br />
            <b-button class="controls" type="submit" @click="register"
              >Create Account</b-button
            >
          <br />
          <div class="error" v-html="error" />

          <p>
            <b>Oh,</b> do you already have an account? <br /><router-link
              to="/login"
              ><button class="controls" id="mobileBtn">
                Log In
              </button></router-link
            >
          </p>
          <router-link to="/"
            ><button id="closeBtn">Cancel</button></router-link
          >
        </form>
      </div>
    </div>
    <Footer />
  </article>
</template>


<script>
//import AuthenticationService from '@/services/AuthenticationService'
import axios from "axios";
import Footer from "@/components/Footer";

export default {
  name: "Register",
  components: {
    Footer,
  },
  data() {
    return {
      email: "",
      username: "",
      password: "",
      firstname: "",
      lastname: "",
      error: null,
    };
  },

  mounted() {
   //  this.checkisLoggedIn();
  },
  methods: {
    checkisLoggedIn() {
      var token = localStorage.getItem("token");
      axios
        .get("http://localhost:5000/api/user/getLoggedUser", {
          headers: {
            Authorization: "Bearer " + token,
          },
        })
        .then(() => {
          this.$router.replace({ name: "WelcomePage" });
        })
        .catch(() => {});
    },

    async register() {
       
      if (this.username == "" || this.password == "" || this.email == "") {
        this.error = "Please make sure no necessary fields are empty!";
        return;
      }


      axios
        .post("http://localhost:5000/register", {
          username: this.username,
          password: this.password,
          firstname: this.firstname,
          lastname: this.lastname,
          email: this.email,
        })
        .then(() => {
           this.$router.push({ name: "Login" });
        })
        .catch((err) => {
          this.error = err.response.data.error;
        });
    },
  },
};
</script>

<style scoped>
.error {
  color: red;
}

.container {
  position: relative;
  margin-top: 50px;
  margin-bottom: 300px;
  width: 600px;
  height: 600px;
  border-radius: 10px;
  font-family: Tahoma, sans-serif;
  line-height: 20px;
  overflow: hidden;
  box-shadow: 0 5px 5px #474747, 1px 5px 5px #474747;
  background: linear-gradient(to bottom, #ffffff, #ccc);
}

.box {
  position: absolute;
  top: -10px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  text-align: center;
  color: rgb(65, 62, 71);
  margin-left: -10px;
}

h2 {
  margin: 15px;
}

p {
  margin: 8px 30px;
  margin-top: 30px;
}

button {
  border-radius: 20px;
  border: 1px solid #a7a7a7;
  background-color: rgb(96, 92, 102);
  color: whitesmoke;
  font-size: 0.8rem;
  font-weight: bold;
  letter-spacing: 1px;
  text-transform: uppercase;
}

button:hover {
  text-decoration: none;
  background-color: rgb(19, 10, 34);
  transition: background-color 0.3s linear;
}

.controls {
  padding: 10px 30px;
  width: auto;
  margin-top: 10px;
}

#closeBtn {
  margin: 0px 0px;
  width: 110px;
  height: 40px;
  font-size: 12px;
  color: rgb(96, 92, 102);
  background-color: rgb(187, 187, 189);
}

#closeBtn:hover {
  background-color: rgb(255, 255, 255);
  transition: background-color 0.3s linear;
}

input {
  margin-top: 10px;
  padding: 7px 15px;
  margin-right: 20px;
  background-color: white;
  border: none;
  width: calc(100% - 130px);
  border-radius: 15px;
  border-bottom: 1px solid #ddd;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.4), 0 -1px 1px #fff, 0 1px 0 #fff;
  overflow: hidden;
  font-size: 12px;
}

input:focus {
  outline: none;
  background-color: white;
}

@media only screen and (max-width: 700px) {
  .container {
    margin-top: 10px;
    width: 90%;
    height: relative;
  }

  .box {
    width: 100%;
    left: 10px;
  }
}
</style>