<template>
  <div id="user-profile">
    <Navbar />
    <template v-if="!invalidUser">
      <template v-if="!ucitano">
        <LoaderItem/>
      </template>
      <template v-else>
        <div class="container">
          <GoBack />
          <div class="title">
            <p id="now-showing">Now showing</p>
            <i>{{ firstName }}</i
            >'s profile
          </div>

          <div class="section">
            <div class="left-section">
              <b-avatar
                id="avatar"
                size="100px"
                variant="light"
                rounded="lg"
              ></b-avatar>
              <br />
              <a id="un">@{{ username }}</a>
              <br />
              <div id="info">
                <p></p>
                <a>name:</a>
                {{ firstName }}
                <br />
                <a>surname:</a> {{ lastName }}
                <p></p>
              </div>
              <template v-if="username == user[0].username">
                <CreateList />
              </template>
              <template v-else>
                <b-button variant="danger" v-if="isfollowing" @click="odprati"
                  >Unfollow</b-button
                >
                <b-button variant="primary" v-else @click="zaprati"
                  >Follow</b-button
                >
              </template>
            </div>
            <div class="right-section">
              <div id="info">
                <a>Biography:</a>
                {{ bio }}
                <p></p>
                <b-list-group>
                  <b-list-group-item
                    class="d-flex justify-content-between align-items-center"
                    >followers:
                    <b-badge variant="primary" pill>{{ numfollowers }}</b-badge>
                  </b-list-group-item>
                  <b-list-group-item
                    class="d-flex justify-content-between align-items-center"
                    >following:
                    <b-badge variant="primary" pill>{{ numfollowing }}</b-badge>
                  </b-list-group-item>
                </b-list-group>
              </div>
              <template v-if="username == user[0].username">
                <div class="settings">
                  <EditBio />
                  <AccountSettings />
                  <EditModal />
                  <p></p>
                </div>
              </template>
            </div>
          </div>
          <div class="bottom">
            <h3>{{ firstName }}'s lists:</h3>
            <template v-if="username == user[0].username || watchedPriv == 1">
              <WatchedList
                :items="movies"
                :un="username"
                :is_public="watchedPriv"
                :listID="watchedID"
              />
              <!-- </div> -->
              <div class="watched">
                <a v-if="watchedPriv === 0">
                  <b-icon icon="lock-fill"></b-icon>this list is private.
                </a>
              </div>
            </template>
            <template v-if="isAllowed()">
              <div class="my-lists" v-for="list in allLists" :key="list.id">
                <h4>
                  <a v-if="list.is_public === 0"
                    ><b-icon icon="lock-fill"></b-icon
                  ></a>
                  <a v-else><b-icon icon="list-stars"></b-icon></a>
                  {{ list.name }}
                </h4>
                <div id="info" class="description">
                  <a>About this list: </a><br />{{ list.description }}
                </div>
                <div class="buttons">
                  <b-button-group>
                    <router-link :to="{ name: 'List', params: { id: list.id } }"
                      ><b-button variant="info">See list</b-button></router-link
                    >
                    <DeleteList :listID="list.id" />
                  </b-button-group>
                </div>
              </div>
            </template>
            <template v-else>
              <div class="my-lists" v-for="list in publicLists" :key="list.id">
                <h4>
                  <b-icon icon="list-stars"></b-icon>
                  {{ list.name }}
                </h4>
                <div id="info" class="description">
                  <a>About this list: </a><br />{{ list.description }}
                </div>
                <div class="buttons">
                  <router-link :to="{ name: 'List', params: { id: list.id } }"
                    ><b-button variant="info">See list</b-button></router-link
                  >
                </div>
              </div>
            </template>
            <p></p>
          </div>
        </div>
      </template>
    </template>
    <template v-else>
      <div class="no-permission">
        <h1>404 Error. The user you are trying to reach doesn't exist.</h1>
      </div>
    </template>
    <Footer />
  </div>
</template>

<script>
import EditBio from "@/components/EditBio";
import CreateList from "@/components/CreateList";
import GoBack from "@/components/GoBack";
import EditModal from "@/components/EditProfile";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import axios from "axios";

import { mapGetters } from "vuex";
import AccountSettings from "@/components/AccountSettings";
import DeleteList from "@/components/DeleteList";
import WatchedList from "@/components/WatchedList";
import LoaderItem from "@/components/LoaderItem";
export default {
  name: "Profile",
  components: {
    Navbar,
    Footer,
    EditModal,
    GoBack,
    CreateList,
    DeleteList,
    WatchedList,
    LoaderItem,
    EditBio,
    AccountSettings,
  },

  data() {
    return {
      id: 0,
      username: this.$route.params.username,
      firstName: "",
      lastName: "",
      bio: "",
      allLists: [],
      publicLists: [],
      // user[0].username: "",
      watchedID: 0,
      watchedPriv: 0,
      movies: [],
      ucitano: false,

      numfollowers: 0,
      numfollowing: 0,
      isfollowing: false,

      invalidUser: false,
      erMsg : null,
    };
  },

  computed: {
    ...mapGetters({
      authenticated: "authenticated",
      user: "user",
    }),
  },

  created() {
    this.loadUser();
    // this.userExists();
    this.loadAllLists();
    this.loadWatchedList();
  },

  methods: {
    getNumFollowers() {
      axios
        .post("http://localhost:5000/api/user/followers", {
          user_id: this.id,
        })
        .then((res) => {
          this.numfollowers = res.data.length;
        });
    },
    getNumFollowing() {
      axios
        .post("http://localhost:5000/api/user/following", {
          user_id: this.id,
        })
        .then((res) => {
          this.numfollowing = res.data.length;
        });
    },

    checkIsFollowing() {
      axios
        .post("http://localhost:5000/api/user/followers", {
          user_id: this.id,
        })
        .then((res) => {
          console.log(res.data);
          if (res.data.length == 0) {
            return;
          } else {
            res.data.forEach((element) => {
              if (element.follower_id == this.user[0].id) {
                this.isfollowing = true;
                return;
              } //mozda je ovde problem ako bude greska
            });
          }
        });
    },

    zaprati() {
      axios
        .post("http://localhost:5000/api/user/follow", {
          user_id: this.user[0].id,
          targetUser_id: this.id,
        })
        .then(() => {
          this.isfollowing = true;
          //location.reload();
        });
    },

    odprati() {
      axios
        .post("http://localhost:5000/api/user/unfollow", {
          user_id: this.user[0].id,
          targetUser_id: this.id,
        })
        .then((res) => {
          console.log(res);
          this.isfollowing = false;
          //location.reload();
        });
    },
    isAllowed() {
      if (
        this.username == this.user[0].username ||
        //this.user[0] ||
        this.user[0].role == "cm" ||
        this.user[0].role == "admin"
      ) {
        return true;
      } else {
        return false; //do sth cool tipa you shall not pass
      }
    },

    loadUser() {
      // console.log(this.username);
      axios
        .post("http://localhost:5000/api/user/username/", {
          username: this.username,
        })
        .then((response) => {
          if (response.data == "") {
            this.invalidUser = true;
            this.ucitano = true;
          } 
          else {
            this.id = parseInt(response.data.id);
            this.username = response.data.username;
            this.firstName = response.data.firstname;
            this.lastName = response.data.lastname;
            this.bio = response.data.bio;
            this.loadWatchedList();
            this.ucitano = true;
            this.invalidUser = false;
            this.checkIsFollowing();
          }
          console.log(this.invalidUser);
        })
        .then(() => {
          this.getNumFollowers();
        })
        .then(() => {
          this.getNumFollowing();
        })
        .catch((err) => {
          this.invalidUser = true;
            this.ucitano = true;
          console.log(err);
          this.erMsg = err;
        })
    },
    loadWatchedList() {
      axios
        .post("http://localhost:5000/api/watchedlist/userID", {
          target_user_id: this.id,
        })
        .then((response) => {
          // console.log(response.data);
          if (response.data.length !== 0) {
            this.watchedID = response.data[0].id;
            this.watchedPriv = response.data[0].is_public;
            // console.log(response.data[0]);
            this.loadWatchedMovies();
          }
        });
    },
    loadWatchedMovies() {
      axios
        .post("http://localhost:5000/api/watchedlist/movies", {
          list_id: this.watchedID,
        })
        .then((response) => {
          this.movies = response.data;
          // this.ucitano = true;
          // console.log(response.data);
        });
    },
    loadAllLists() {
      console.log(this.username);
      axios
        .get("http://localhost:5000/api/mylist/" + this.username)
        .then((response) => {
          // console.log(response.data.filter((list) => list.is_public === 1))
          this.publicLists = response.data.filter(
            (list) => list.is_public === 1
          );
          this.allLists = response.data;
        });
    },
  },
};
</script>

<style scoped>
.no-permission {
  margin: 500px 200px 400px 200px;
}
#user-profile {
  background-image: url("../assets/popcorn.png");
  background-repeat: no-repeat;
  background-size: 30%;
  background-position-x: right;
  background-position-y: bottom;
  display: flex;
  flex-direction: column;
  cursor: default;
}

.container {
  display: flex;
  flex-direction: column;
  background-image: linear-gradient(
    to top left,
    rgb(255, 255, 255),
    rgb(212, 211, 211)
  );
  max-width: 888px;
  background-color: ivory;
  padding: 40px 10px;
  font-family: Trebuchet MS, sans-serif;
  border-bottom-right-radius: 15px;
  border-bottom-left-radius: 15px;
  margin-bottom: 300px;
}

.title {
  background-image: linear-gradient(
    to top left,
    rgb(37, 106, 211),
    rgba(167, 163, 185, 0.178)
  );
  padding: 90px 0 30px 0;
  font-size: 32px;
  text-align: center;
  float: center;
  font-weight: 600;
  color: rgb(223, 223, 223);
  text-shadow: 1px 2px 3px #30303081;
  border: 1px solid rgba(128, 128, 128, 0.548);
  border-radius: 10px;
  -webkit-text-stroke: 1px rgb(6, 2, 90);
}

.title #now-showing {
  margin-bottom: 0px;
  line-height: 20px;
  color: rgb(31, 31, 31);
  text-shadow: 1px 2px 2px #30303081;
  text-transform: uppercase;
  -webkit-text-stroke: 0.1px rgb(212, 209, 255);
}

/* ************** TOP SECTION ********** */
.section {
  display: flex;
  padding: 35px;
  margin: 0px 60px;
  border-right: 1px solid rgb(148, 148, 148);
  border-left: 1px solid rgb(148, 148, 148);
}

.left-section,
.right-section {
  width: 50%;
  flex: 1;
  padding: 0px;
}

.left-section {
  font-size: 25px;
  text-align: center;
}
#avatar {
  border: 5px double rgb(148, 148, 148);
}
#un {
  color: rgb(255, 255, 255);
  font-weight: 600;
  text-shadow: 1px 1px 1px #30303081;
  -webkit-text-stroke: 0.7px rgb(41, 35, 112);
}

#info {
  float: center;
  text-align: left;
  font-size: 21px;
  line-height: 24px;
}

.left-section #info {
  margin: 5px 45px;
  text-align: center;
  border-top: 1px solid rgb(117, 117, 117);
}

#info a {
  color: rgb(125, 139, 187);
  font-style: oblique;
  font-weight: 800;
  text-transform: lowercase;
  -webkit-text-stroke: 0.4px rgb(73, 73, 73);
}

.right-section {
  margin: 20px 10px auto 10px;
  font-size: 20px;
  font-family: Trebuchet MS, sans-serif;
}

.right-section #info {
  background-color: whitesmoke;
  border: 1px solid rgb(194, 194, 194);
  border-radius: 15px;
  padding: 20px;
}

.settings {
  justify-content: center;
  padding: 10px 0px 0px 0px;
  display: flex;
  flex-direction: row;
}

/* ********** BOTTOM SECTION *********** */

.bottom {
  display: flex;
  flex-direction: column;
  margin: 0px 60px;
}

h3 {
  text-align: left;
  margin: 0;
  padding: 10px;
  font-weight: 600;
  text-transform: uppercase;
  color: rgb(121, 121, 121);
  text-shadow: 1px 2px 3px #30303081;
  border: 1px double rgba(148, 148, 148, 0.61);
  background-color: rgba(167, 163, 185, 0.178);
  -webkit-text-stroke: 0.7px rgb(212, 209, 255);
}

h3 a {
  float: right;
}

.my-lists {
  margin-top: -40px;
  padding-left: 10px;
  padding-top: 60px;
  border-right: 1px solid rgb(148, 148, 148);
  border-left: 1px solid rgb(148, 148, 148);
}

.buttons {
  display: flex;
  flex-direction: row;
  text-align: right;
  padding: 10px;
}

.watched {
  padding: 25px 0px 10px 30px;
  color: rgb(78, 154, 204);
  border-bottom: 1px solid rgb(148, 148, 148);
}

h4 {
  font-size: 25px;
  padding: 10px 0px 0px 5px;
  color: rgb(43, 43, 43);
  text-transform: uppercase;
  text-shadow: 0px 1px 1px #30303081;
  font-weight: 600;
  -webkit-text-stroke: 0.1px rgb(255, 255, 255);
}

.description {
  float: left;
  margin: 0px 20px 60px 10px;
  width: 65%;
  color: rgb(15, 15, 15);
  border-bottom: 1px dashed grey;
}

/* ************RESPONSIVE************ */
@media only screen and (max-width: 900px) {
  .container {
    flex-direction: column;
  }
  .section {
    flex-direction: column;
  }

  .left-section,
  .right-section {
    width: 100%;
  }

  #info {
    font-size: 25px;
    line-height: 26px;
  }
}
</style>