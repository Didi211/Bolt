import Vue from 'vue'
import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'
import App from './App.vue'

import { sync } from 'vuex-router-sync'
import store from './store/store'

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import router from './router'
import PulseLoader from 'vue-spinner/src/PulseLoader.vue'

require('./store/subscriber')

window.axios = require('axios');
//ako hoces odradi axios defaulturl!, ili ovde ili u api folderu

store.dispatch('attempt', localStorage.getItem('token'))

sync(store, router)

Vue.config.productionTip = false

Vue.use(BootstrapVue)
Vue.use(IconsPlugin)

new Vue({
  router,
  store,
  components: {
    PulseLoader,
  },
  render: h => h(App)
}).$mount('#app')

window.axios.interceptors.request.use(
  function(config) {
    const token = localStorage.getItem('token')
    if (token) config.headers.Authorization = `Bearer ${token}`
    return config
  },

  function(error) {
    return Promise.reject(error)
  }
)