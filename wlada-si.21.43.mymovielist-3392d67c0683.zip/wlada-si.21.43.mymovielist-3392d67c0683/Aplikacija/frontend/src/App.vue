<template>
  <div>
    <transition name="moveUp">
      <router-view :key="$route.path" />
    </transition>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
};
</script>


<style>
body {
  /* background-image: linear-gradient(
    to right,
    rgba(246, 241, 182, 1),
    rgba(154, 50, 50, 1)
  ); */
  background-image: linear-gradient(
    to bottom right,
    rgb(0, 0, 0),
    rgb(11, 3, 26)
  );
  /* background-repeat: no-repeat; */
  margin: 0;
}

.m-0 {
  margin: 0;
}

#app {
  font-family: Tahoma, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: white;
}


.moveUp-enter-active{
  animation: fadeIn 1s ease-in;
}

@keyframes fadeIn {
  0%{
    opacity: 0.2;
  }
  50% {
    opacity: 0.8;
  }
  100%{
    opacity: 1;
  }
}


</style>
