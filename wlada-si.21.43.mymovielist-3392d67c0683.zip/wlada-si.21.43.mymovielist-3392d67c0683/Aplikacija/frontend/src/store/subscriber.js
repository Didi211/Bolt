import store from './store'
import axios from 'axios'

store.subscribe((mutation) => {
    switch(mutation.type) {
        case 'setToken':
            if(mutation.payload){ //mutation.payload u ovom slucaju token!
                axios.defaults.headers.common['Authorization'] = 'Bearer ' + mutation.payload
                localStorage.setItem('token', mutation.payload)
            }
            else {
                console.log("ISTEKLO BATICE AJDE!")
                axios.defaults.headers.common['Authorization'] = null
                localStorage.removeItem('token')
            }
    }
})