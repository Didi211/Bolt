import axios from 'axios'
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
namespaced: true,
strict: true,
state: {
    token: null,
    user: null,
    isUserLoggedIn: false,
    role: null
},

getters: {
    authenticated(state){
        return state.token && state.user
    },
    user (state) {
        return state.user
    },
    token (state) {
        return state.token
    },
    role(state){
        return state.role
    }
},

mutations: {
    setToken(state, token){
        state.token = token;
        if(token){
            state.isUserLoggedIn = true
        }
        else{
            state.isUserLoggedIn = false
        }
    },
    setUser(state, user){
        state.user = user;
    },
    setRole(state, role){
        state.role = role
    }
},
actions: {

    /*async registerAcc(_, credentials){

        let response = await axios.post('http://localhost:5000/register', credentials)

       //console.log(response.data.token)
       //return dispatch('attempt', response.data.token)

    },*/

    async signIn ({dispatch}, credentials){
        let response = await axios.post('http://localhost:5000/login', credentials)

       // console.log(response.data)
       return dispatch('attempt', response.data.token)
    },

    async attempt({commit, state}, token){

        if(token){
            commit('setToken', token)
        }

        if(!state.token){
            return
        }

        try{
            let response =  await axios.get("http://localhost:5000/api/user/getLoggedUser")

            commit('setUser', response.data)
            commit('setRole', response.data[0].role)
            
        }
        catch(e){
            commit('setToken', null)
            commit('setUser', null)
            commit('setRole', null)
            
        }

    },

   /* setToken ({commit}, token){
        commit('setToken', token)
    },
    setUser ({commit}, user){
        commit('setUser', user)
    }*/
}

})