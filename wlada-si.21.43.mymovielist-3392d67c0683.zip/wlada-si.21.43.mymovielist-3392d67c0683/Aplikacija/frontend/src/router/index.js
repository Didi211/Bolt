import Vue from 'vue'
import VueRouter from 'vue-router'
import WelcomePage from '../views/WelcomePage.vue'
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import Browse from '../views/Browse.vue'
import Movie from '../views/Movie.vue'
import Profile from '../views/Profile.vue'
import List from '../views/List.vue'
import Admin from '../views/Admin.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'WelcomePage',
    component: WelcomePage
  },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/browse',
    name: 'Browse',
    component: Browse
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/movie/:id',
    name: 'Movie',
    component: Movie,
    props: { default: true }
  },
  {
    path: '/:username',
    name: 'Profile',
    component: Profile
  },
  {
    path: '/list/:id',
    name: 'List',
    component: List,
    props: { default: true }
  },
  {
    path: '/admins/admin',
    name: 'Admin',
    component: Admin
  }
]

const router = new VueRouter({
  mode: "history",
  routes: routes
})

export default router
